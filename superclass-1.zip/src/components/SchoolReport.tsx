import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import { CLASSES, MONTHS, SEMESTERS, gradeOf, fmtAvg, getAvg, getThreeWorkingDates } from "../lib/constants";
import { Student, ScoreMap, TeacherProfile } from "../types";

interface SchoolReportProps {
  teacher: TeacherProfile | null;
}

interface ClassGradeStat {
  className: string;
  totalStudents: number;
  femaleStudents: number;
  gradeCounts: { A: number; B: number; C: number; D: number; E: number; F: number };
  femaleGradeCounts: { A: number; B: number; C: number; D: number; E: number; F: number };
  avgScore: number | null;
  loading: boolean;
}

export const SchoolReport: React.FC<SchoolReportProps> = ({ teacher }) => {
  const [semesterId, setSemesterId] = useState<string>("s1");
  const [selMonth, setSelMonth] = useState<number>(3); // Default March / មីនា
  const [classStats, setClassStats] = useState<ClassGradeStat[]>([]);
  const [loadingAll, setLoadingAll] = useState<boolean>(false);
  const [sig1Role, setSig1Role] = useState<string>("អ្នករៀបចំរបាយការណ៍");
  const [dateMode, setDateMode] = useState<"auto" | "dots">("auto");

  const curSem = SEMESTERS.find((s) => s.id === semesterId) || SEMESTERS[0];
  const dates = getThreeWorkingDates(selMonth);
  const isTeacherOrOrganizer = sig1Role === "អ្នករៀបចំរបាយការណ៍" || sig1Role === "គ្រូប្រចាំថ្នាក់";

  const fetchSchoolData = async () => {
    setLoadingAll(true);
    const stats: ClassGradeStat[] = [];

    for (const cls of CLASSES) {
      try {
        // Fetch students for this class
        const stuSnap = await getDocs(collection(db, "classes", cls, "students"));
        const students: Student[] = [];
        stuSnap.forEach((docSnap) => {
          students.push({ id: docSnap.id, ...docSnap.data() } as Student);
        });

        if (students.length === 0) {
          stats.push({
            className: cls,
            totalStudents: 0,
            femaleStudents: 0,
            gradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
            femaleGradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
            avgScore: null,
            loading: false,
          });
          continue;
        }

        // Fetch scores for this month
        const scoresSnap = await getDocs(
          collection(db, "classes", cls, "semesters", semesterId, "months", String(selMonth), "scores")
        );
        const scoresMap: Record<string, ScoreMap> = {};
        scoresSnap.forEach((docSnap) => {
          scoresMap[docSnap.id] = docSnap.data().scores || {};
        });

        const femaleCount = students.filter((s) => s.gender === "ស្រី").length;
        const counts = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
        const femaleCounts = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
        let sumAvgs = 0;
        let countAvgs = 0;

        students.forEach((s) => {
          const avg = getAvg(s.id, students, scoresMap);
          if (avg > 0 || Object.keys(scoresMap[s.id] || {}).length > 0) {
            sumAvgs += avg;
            countAvgs++;
            const g = gradeOf(avg).l as "A" | "B" | "C" | "D" | "E" | "F";
            if (counts[g] !== undefined) {
              counts[g]++;
              if (s.gender === "ស្រី") {
                femaleCounts[g]++;
              }
            }
          }
        });

        stats.push({
          className: cls,
          totalStudents: students.length,
          femaleStudents: femaleCount,
          gradeCounts: counts,
          femaleGradeCounts: femaleCounts,
          avgScore: countAvgs > 0 ? sumAvgs / countAvgs : null,
          loading: false,
        });
      } catch (err) {
        console.warn(`Error fetching stats for class ${cls}:`, err);
        stats.push({
          className: cls,
          totalStudents: 0,
          femaleStudents: 0,
          gradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
          femaleGradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
          avgScore: null,
          loading: false,
        });
      }
    }

    setClassStats(stats);
    setLoadingAll(false);
  };

  useEffect(() => {
    fetchSchoolData();
  }, [semesterId, selMonth]);

  // Aggregate totals
  const totalStudents = classStats.reduce((a, b) => a + b.totalStudents, 0);
  const totalFemales = classStats.reduce((a, b) => a + b.femaleStudents, 0);
  const totalGrades = classStats.reduce(
    (acc, cur) => {
      acc.A += cur.gradeCounts.A;
      acc.B += cur.gradeCounts.B;
      acc.C += cur.gradeCounts.C;
      acc.D += cur.gradeCounts.D;
      acc.E += cur.gradeCounts.E;
      acc.F += cur.gradeCounts.F;
      return acc;
    },
    { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 }
  );

  const totalEvaluated = totalGrades.A + totalGrades.B + totalGrades.C + totalGrades.D + totalGrades.E + totalGrades.F;
  const defCount = totalGrades.D + totalGrades.E + totalGrades.F;
  const defPct = totalEvaluated > 0 ? ((defCount / totalEvaluated) * 100).toFixed(1) : "0";
  const passCount = totalGrades.A + totalGrades.B + totalGrades.C + totalGrades.D + totalGrades.E;
  const passPct = totalEvaluated > 0 ? ((passCount / totalEvaluated) * 100).toFixed(1) : "0";

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 max-w-7xl mx-auto space-y-4">
      {/* Header controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs no-print flex flex-wrap justify-between items-center gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
            🏫 របាយការណ៍សាលារៀន (លទ្ធផលនិទ្ទេសតាមខែ គ្រប់ថ្នាក់ទាំងអស់)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {teacher?.school || "សាលាបឋមសិក្សា"} — ពិនិត្យស្ថិតិនtests និទ្ទេស A B C D E F និងវាយតម្លៃគុណភាពអប់រំសាលា
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Semester Selector */}
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
            {SEMESTERS.filter((s) => s.id !== "annual").map((sm) => (
              <button
                key={sm.id}
                onClick={() => {
                  setSemesterId(sm.id);
                  setSelMonth(sm.months[0]);
                }}
                className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                  semesterId === sm.id
                    ? "bg-blue-600 text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                }`}
              >
                {sm.label}
              </button>
            ))}
          </div>

          {/* Month Selector */}
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
            {curSem.months.map((mIdx) => (
              <button
                key={mIdx}
                onClick={() => setSelMonth(mIdx)}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition ${
                  selMonth === mIdx
                    ? "bg-slate-900 text-white shadow-xs dark:bg-blue-500"
                    : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                }`}
              >
                ខែ{MONTHS[mIdx]}
              </button>
            ))}
          </div>

          {/* Signatory #1 Role Selector */}
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
            <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">✍️ ហត្ថលេខាទី១:</span>
            <select
              value={sig1Role}
              onChange={(e) => setSig1Role(e.target.value)}
              className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
            >
              <option value="អ្នករៀបចំរបាយការណ៍">អ្នករៀបចំរបាយការណ៍</option>
              <option value="គ្រូប្រចាំថ្នាក់">គ្រូប្រចាំថ្នាក់</option>
              <option value="មន្ត្រីការិយាល័យ">មន្ត្រីការិយាល័យ</option>
              <option value="លេខាធិការ">លេខាធិការ</option>
              <option value="បេឡាធិការ">បេឡាធិការ</option>
              <option value="ហេរញ្ញិក">ហេរញ្ញិក</option>
            </select>
          </div>

          {/* Date Format Selector */}
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
            <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">📅 កាលបរិច្ឆេទ:</span>
            <select
              value={dateMode}
              onChange={(e) => setDateMode(e.target.value as "auto" | "dots")}
              className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
            >
              <option value="auto">ស្វ័យប្រវត្តិ (តាមខែ)</option>
              <option value="dots">ចុចជួរ (... បោះពុម្ព)</option>
            </select>
          </div>

          <button
            onClick={fetchSchoolData}
            className="px-2 py-1 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[10px] font-bold rounded-md border border-slate-300 dark:border-slate-700 flex items-center gap-1"
          >
            🔄 ធ្វើបច្ចុប្បន្នភាព
          </button>

          <button
            onClick={handlePrint}
            className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold rounded-md shadow-xs flex items-center gap-1"
          >
            🖨️ បោះពុម្ពរបាយការណ៍សាលា
          </button>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 no-print">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សសរុប (គ្រប់ថ្នាក់)</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            {totalStudents} <span className="text-xs text-slate-500 font-normal">(ស្រី {totalFemales})</span>
          </div>
          <div className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">បានវាយតម្លៃ {totalEvaluated} នាក់</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">អត្រាសិស្សជាប់ (A-E)</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {passPct}% <span className="text-xs text-slate-500 font-normal">({passCount} នាក់)</span>
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">និទ្ទេស A-E</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សរៀនយឺត (DEF)</div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
            {defCount} <span className="text-xs font-normal text-amber-700">({defPct}%)</span>
          </div>
          <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">ត្រូវការផែនការជួយបំប៉ន</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">និទ្ទេស A & B (ល្អប្រសើរ)</div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
            {totalGrades.A + totalGrades.B}{" "}
            <span className="text-xs text-slate-500 font-normal">
              ({totalEvaluated > 0 ? (((totalGrades.A + totalGrades.B) / totalEvaluated) * 100).toFixed(1) : 0}%)
            </span>
          </div>
          <div className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">A: {totalGrades.A} | B: {totalGrades.B}</div>
        </div>
      </div>

      {/* Main Print Container & Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-slate-900 dark:text-slate-100">
        {/* Print Header */}
        <div className="text-center w-full mb-4">
          <h2 className="text-sm font-black text-blue-900 dark:text-blue-400 leading-snug">
            ព្រះរាជាណាចក្រកម្ពុជា
            <br />
            ជាតិ សាសនា ព្រះមហាក្សត្រ
          </h2>
          <div className="text-[10px] text-amber-800 dark:text-amber-500 mt-0.5 font-normal">꧁ ༺ ༻ ꧂</div>
        </div>

        <div className="flex justify-between items-start gap-4 mb-2">
          <div className="text-xs text-slate-900 dark:text-slate-200 leading-snug font-bold">
            <div>រដ្ឋបាលស្រុកភ្នំស្រុក</div>
            <div>ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក</div>
            <div>កម្រងស្ពានស្រែង</div>
            <div>{teacher?.school || "សាលាបឋមសិក្សា"}</div>
          </div>
        </div>

        <hr className="border-t-2 border-slate-900 dark:border-slate-700 mb-3" />

        <div className="text-center mb-4 space-y-1">
          <h3 className="font-black text-base text-blue-800 dark:text-blue-400 uppercase mt-2">
            របាយការណ៍សរុបលទ្ធផលនិទ្ទេសសិក្សា (ខែ{MONTHS[selMonth]} {curSem.label})
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">គ្រប់ថ្នាក់ទាំងអស់ ក្នុងសាលារៀន</p>
        </div>

        {loadingAll ? (
          <div className="py-12 text-center text-slate-500 space-y-2">
            <div className="text-2xl animate-spin inline-block">⏳</div>
            <div className="text-xs font-semibold">កំពុងទាញយកទិន្នន័យគ្រប់ថ្នាក់ទាំងអស់ពី Firestore...</div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-slate-300 text-xs">
              <thead>
                <tr className="bg-blue-100/90 border border-slate-300 text-slate-900 font-bold">
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-8">
                    ល.រ
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-2 text-center min-w-[60px]">
                    ថ្នាក់
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-12">
                    សិស្សសរុប
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-10">
                    ស្រី
                  </th>
                  <th colSpan={6} className="border border-slate-300 py-1 px-1 text-center bg-blue-200/80">
                    ចំនួនសិស្សទទួលបាននិទ្ទេស (A - F)
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-14 bg-emerald-100">
                    អត្រាជាប់ (A-E)
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-14 bg-amber-100">
                    សិស្សរៀនយឺត (DEF)
                  </th>
                  <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center min-w-[60px]">
                    មធ្យមភាគថ្នាក់
                  </th>
                </tr>
                <tr className="bg-blue-50 border border-slate-300 text-slate-800 font-bold">
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-blue-700 bg-blue-50">
                    និទ្ទេសA
                  </th>
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-cyan-700 bg-cyan-50">
                    និទ្ទេសB
                  </th>
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-emerald-700 bg-emerald-50">
                    និទ្ទេសC
                  </th>
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-amber-700 bg-amber-50">
                    និទ្ទេសD
                  </th>
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-orange-700 bg-orange-50">
                    និទ្ទេសE
                  </th>
                  <th className="border border-slate-300 py-1.5 px-1 text-center text-red-700 bg-red-50">
                    និទ្ទេសF
                  </th>
                </tr>
              </thead>
              <tbody>
                {classStats.map((st, idx) => {
                  const evalCount =
                    st.gradeCounts.A +
                    st.gradeCounts.B +
                    st.gradeCounts.C +
                    st.gradeCounts.D +
                    st.gradeCounts.E +
                    st.gradeCounts.F;
                  const cPass = st.gradeCounts.A + st.gradeCounts.B + st.gradeCounts.C + st.gradeCounts.D + st.gradeCounts.E;
                  const cPassPct = evalCount > 0 ? ((cPass / evalCount) * 100).toFixed(0) + "%" : "—";
                  const cDEF = st.gradeCounts.D + st.gradeCounts.E + st.gradeCounts.F;

                  return (
                    <tr key={st.className} className={idx % 2 === 0 ? "bg-slate-50/50" : "bg-white"}>
                      <td className="border border-slate-300 py-2 px-1 text-center font-medium text-slate-500">
                        {idx + 1}
                      </td>
                      <td className="border border-slate-300 py-2 px-2 text-center font-extrabold text-blue-900">
                        ថ្នាក់ {st.className}
                      </td>
                      <td className="border border-slate-300 py-2 px-1 text-center font-bold">{st.totalStudents}</td>
                      <td className="border border-slate-300 py-2 px-1 text-center text-slate-700">{st.femaleStudents}</td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-blue-700 bg-blue-50/30">
                        {st.gradeCounts.A > 0 ? (
                          <span>
                            {st.gradeCounts.A}{" "}
                            <span className="text-[10px] text-blue-500 font-normal">
                              ({((st.gradeCounts.A / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-cyan-700 bg-cyan-50/30">
                        {st.gradeCounts.B > 0 ? (
                          <span>
                            {st.gradeCounts.B}{" "}
                            <span className="text-[10px] text-cyan-600 font-normal">
                              ({((st.gradeCounts.B / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-emerald-700 bg-emerald-50/30">
                        {st.gradeCounts.C > 0 ? (
                          <span>
                            {st.gradeCounts.C}{" "}
                            <span className="text-[10px] text-emerald-600 font-normal">
                              ({((st.gradeCounts.C / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-amber-700 bg-amber-50/30">
                        {st.gradeCounts.D > 0 ? (
                          <span>
                            {st.gradeCounts.D}{" "}
                            <span className="text-[10px] text-amber-600 font-normal">
                              ({((st.gradeCounts.D / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-orange-700 bg-orange-50/30">
                        {st.gradeCounts.E > 0 ? (
                          <span>
                            {st.gradeCounts.E}{" "}
                            <span className="text-[10px] text-orange-600 font-normal">
                              ({((st.gradeCounts.E / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-red-700 bg-red-50/30">
                        {st.gradeCounts.F > 0 ? (
                          <span>
                            {st.gradeCounts.F}{" "}
                            <span className="text-[10px] text-red-500 font-normal">
                              ({((st.gradeCounts.F / (evalCount || 1)) * 100).toFixed(0)}%)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-300">0</span>
                        )}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-black text-emerald-800 bg-emerald-50/60">
                        {cPassPct}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-black text-amber-800 bg-amber-50/60">
                        {cDEF > 0 ? `${cDEF} នាក់` : "០"}
                      </td>

                      <td className="border border-slate-300 py-2 px-1 text-center font-bold text-slate-800">
                        {st.avgScore !== null ? fmtAvg(st.avgScore) : "—"}
                      </td>
                    </tr>
                  );
                })}

                {/* Total Row */}
                <tr className="bg-blue-100/90 font-black text-slate-900 border-t-2 border-slate-400">
                  <td colSpan={2} className="border border-slate-300 py-2.5 px-2 text-center">
                    សរុបសាលា
                  </td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center">{totalStudents}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center">{totalFemales}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-blue-900">{totalGrades.A}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-cyan-900">{totalGrades.B}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-emerald-900">{totalGrades.C}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-amber-900">{totalGrades.D}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-orange-900">{totalGrades.E}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-red-900">{totalGrades.F}</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-emerald-900">{passPct}%</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center text-amber-900">{defCount} នាក់</td>
                  <td className="border border-slate-300 py-2.5 px-1 text-center">—</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {/* Signature Footer for Official Printing */}
        <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between gap-8 text-xs text-slate-800 dark:text-slate-200">
          {/* Left Block: នាយក/នាយិកាសាលា */}
          <div className="flex-1 text-center">
            <div className="font-bold text-sm text-slate-900 dark:text-white">បានឃើញ និងឯកភាព</div>
            
            {isTeacherOrOrganizer ? (
              <div className="my-2 text-left text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                <div>{dateMode === "auto" ? dates.d2.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}</div>
                <div>{dateMode === "auto" ? dates.d2.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}</div>
              </div>
            ) : (
              <div className="my-2 min-h-[32px]"></div>
            )}

            <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">
              នាយក/នាយិកាសាលា
            </div>
            <div className="h-16"></div>
          </div>

          {/* Right Block: ហត្ថលេខាទី១ (អ្នករៀបចំ/គ្រូប្រចាំថ្នាក់/មន្ត្រី...) */}
          <div className="flex-1 text-center">
            <div className="my-2 text-left text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
              <div>{dateMode === "auto" ? dates.d0.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}</div>
              <div>{dateMode === "auto" ? dates.d0.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}</div>
            </div>

            <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">
              {sig1Role}
            </div>
            <div className="font-extrabold text-blue-950 dark:text-blue-300 mt-12">
              {teacher?.fullName || "គ្រូបង្រៀន"}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
