import React, { useState, useMemo } from "react";
import { Student, ScoreMap, TeacherProfile } from "../types";
import {
  SUBJECTS,
  SEMESTERS,
  MONTHS,
  gradeOf,
  resultOf,
  fmtAvg,
  toKhNum,
  truncate2,
  computeReportStats,
} from "../lib/constants";
import { printHTML } from "../lib/printUtils";

interface PerformanceSummaryProps {
  students: Student[];
  allMonthsScores: Record<string, Record<string, ScoreMap>>;
  scoresMap: Record<string, ScoreMap>;
  selClass: string;
  teacher?: TeacherProfile | null;
  honorPhotos?: Record<string, string>;
  onFetchAllMonths?: () => void;
}

export interface StudentPerformance {
  student: Student;
  rank: number;
  s1Avg: number | null;
  s2Avg: number | null;
  cumAvg: number;
  grade: { l: string; c: string };
  result: "ជាប់" | "ធ្លាក់";
  subjectAvgs: Record<string, number | null>;
  subjectCount: number;
  trend: "up" | "down" | "neutral" | "none";
  trendDiff: number;
}

export const PerformanceSummary: React.FC<PerformanceSummaryProps> = ({
  students,
  allMonthsScores,
  scoresMap,
  selClass,
  teacher,
  honorPhotos = {},
  onFetchAllMonths,
}) => {
  // Active Tab View within Performance Summary
  const [activeTab, setActiveTab] = useState<"ranking" | "matrix" | "top5" | "analytics">("ranking");

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState("");
  const [genderFilter, setGenderFilter] = useState<"all" | "ប្រុស" | "ស្រី">("all");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"rank" | "name" | "s1" | "s2" | "cum">("rank");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [displayMode, setDisplayMode] = useState<"avg" | "grade">("avg");

  // Selected Student Modal
  const [selectedStudent, setSelectedStudent] = useState<StudentPerformance | null>(null);

  // Trigger fetch of all months on mount if not loaded
  React.useEffect(() => {
    if (onFetchAllMonths) {
      onFetchAllMonths();
    }
  }, [onFetchAllMonths]);

  // 1. Compute Cumulative Scores and Averages per Student
  const performanceData = useMemo(() => {
    if (!students || students.length === 0) return [];

    const s1Months = SEMESTERS.find((s) => s.id === "s1")?.months || [0, 1, 2, 3, 4, 5];
    const s2Months = SEMESTERS.find((s) => s.id === "s2")?.months || [6, 7, 8, 9, 10, 11, 12];

    const calculateStudentPerformance = (s: Student): StudentPerformance => {
      const subjectScoresSum: Record<string, number> = {};
      const subjectScoresCount: Record<string, number> = {};

      SUBJECTS.forEach((subj) => {
        subjectScoresSum[subj] = 0;
        subjectScoresCount[subj] = 0;
      });

      // Track monthly averages for S1 and S2
      const s1MonthAvgs: number[] = [];
      const s2MonthAvgs: number[] = [];

      // Process S1 Months
      s1Months.forEach((mIdx) => {
        const key = `s1_${mIdx}`;
        const monthScores = allMonthsScores[key]?.[s.id] || (mIdx === 3 ? scoresMap[s.id] : undefined);
        if (monthScores) {
          let mSum = 0;
          let mCount = 0;
          SUBJECTS.forEach((subj) => {
            const v = monthScores[subj];
            if (v !== undefined && v !== "" && v !== null && !isNaN(Number(v))) {
              const num = Number(v);
              subjectScoresSum[subj] += num;
              subjectScoresCount[subj] += 1;
              mSum += num;
              mCount += 1;
            }
          });
          if (mCount > 0) {
            s1MonthAvgs.push(mSum / mCount);
          }
        }
      });

      // Process S2 Months
      s2Months.forEach((mIdx) => {
        const key = `s2_${mIdx}`;
        const monthScores = allMonthsScores[key]?.[s.id] || (mIdx === 7 ? scoresMap[s.id] : undefined);
        if (monthScores) {
          let mSum = 0;
          let mCount = 0;
          SUBJECTS.forEach((subj) => {
            const v = monthScores[subj];
            if (v !== undefined && v !== "" && v !== null && !isNaN(Number(v))) {
              const num = Number(v);
              subjectScoresSum[subj] += num;
              subjectScoresCount[subj] += 1;
              mSum += num;
              mCount += 1;
            }
          });
          if (mCount > 0) {
            s2MonthAvgs.push(mSum / mCount);
          }
        }
      });

      // Also check fallback scoresMap if no month data was found
      if (s1MonthAvgs.length === 0 && s2MonthAvgs.length === 0) {
        const curScores = scoresMap[s.id];
        if (curScores) {
          let mSum = 0;
          let mCount = 0;
          SUBJECTS.forEach((subj) => {
            const v = curScores[subj];
            if (v !== undefined && v !== "" && v !== null && !isNaN(Number(v))) {
              const num = Number(v);
              subjectScoresSum[subj] += num;
              subjectScoresCount[subj] += 1;
              mSum += num;
              mCount += 1;
            }
          });
          if (mCount > 0) {
            s1MonthAvgs.push(mSum / mCount);
          }
        }
      }

      // Per-subject averages
      const subjectAvgs: Record<string, number | null> = {};
      let totalValidSubjects = 0;
      let cumSumSubjects = 0;

      SUBJECTS.forEach((subj) => {
        if (subjectScoresCount[subj] > 0) {
          const avg = truncate2(subjectScoresSum[subj] / subjectScoresCount[subj]);
          subjectAvgs[subj] = avg;
          cumSumSubjects += avg;
          totalValidSubjects += 1;
        } else {
          subjectAvgs[subj] = null;
        }
      });

      // S1 Average
      const s1Avg =
        s1MonthAvgs.length > 0
          ? truncate2(s1MonthAvgs.reduce((a, b) => a + b, 0) / s1MonthAvgs.length)
          : null;

      // S2 Average
      const s2Avg =
        s2MonthAvgs.length > 0
          ? truncate2(s2MonthAvgs.reduce((a, b) => a + b, 0) / s2MonthAvgs.length)
          : null;

      // Cumulative Overall Average
      let cumAvg = 0;
      if (s1Avg !== null && s2Avg !== null) {
        cumAvg = truncate2((s1Avg + s2Avg) / 2);
      } else if (s1Avg !== null) {
        cumAvg = s1Avg;
      } else if (s2Avg !== null) {
        cumAvg = s2Avg;
      } else if (totalValidSubjects > 0) {
        cumAvg = truncate2(cumSumSubjects / totalValidSubjects);
      }

      const grade = gradeOf(cumAvg);
      const result = resultOf(cumAvg) as "ជាប់" | "ធ្លាក់";

      // Trend comparison S1 vs S2
      let trend: "up" | "down" | "neutral" | "none" = "none";
      let trendDiff = 0;
      if (s1Avg !== null && s2Avg !== null) {
        trendDiff = truncate2(s2Avg - s1Avg);
        if (trendDiff > 0.1) trend = "up";
        else if (trendDiff < -0.1) trend = "down";
        else trend = "neutral";
      }

      return {
        student: s,
        rank: 0,
        s1Avg,
        s2Avg,
        cumAvg,
        grade,
        result,
        subjectAvgs,
        subjectCount: totalValidSubjects,
        trend,
        trendDiff,
      };
    };

    const list = students.map(calculateStudentPerformance);

    // Sort to determine ranks
    const sortedForRank = [...list].sort((a, b) => b.cumAvg - a.cumAvg);
    const rankMap: Record<string, number> = {};
    let currentRank = 1;

    sortedForRank.forEach((item, index) => {
      if (
        index > 0 &&
        item.cumAvg === sortedForRank[index - 1].cumAvg &&
        item.cumAvg > 0
      ) {
        rankMap[item.student.id] = rankMap[sortedForRank[index - 1].student.id];
      } else {
        rankMap[item.student.id] = currentRank;
      }
      currentRank++;
    });

    return list.map((item) => ({
      ...item,
      rank: rankMap[item.student.id] || 0,
    }));
  }, [students, allMonthsScores, scoresMap]);

  // 2. Class Summary Metrics
  const classMetrics = useMemo(() => {
    if (!performanceData.length) {
      return {
        total: 0,
        avgCum: "0.00",
        passCount: 0,
        passPct: 0,
        femalePassCount: 0,
        topStudent: null,
        bestSubject: "—",
        lowestSubject: "—",
        gradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
      };
    }

    const total = performanceData.length;
    const validCumAvgs = performanceData.map((p) => p.cumAvg).filter((v) => v > 0);
    const avgCumNum =
      validCumAvgs.length > 0
        ? validCumAvgs.reduce((a, b) => a + b, 0) / validCumAvgs.length
        : 0;

    const passList = performanceData.filter((p) => p.result === "ជាប់");
    const femalePass = passList.filter((p) => p.student.gender === "ស្រី").length;
    const passPct = Math.round((passList.length / total) * 100);

    const sortedByRank = [...performanceData].sort((a, b) => a.rank - b.rank);
    const topStudent = sortedByRank[0] || null;

    // Calculate subject averages across class
    const subjTotals: Record<string, { sum: number; count: number }> = {};
    SUBJECTS.forEach((subj) => {
      subjTotals[subj] = { sum: 0, count: 0 };
    });

    performanceData.forEach((p) => {
      SUBJECTS.forEach((subj) => {
        const val = p.subjectAvgs[subj];
        if (val !== null && val !== undefined) {
          subjTotals[subj].sum += val;
          subjTotals[subj].count += 1;
        }
      });
    });

    let maxSubjAvg = -1;
    let bestSubject = "—";
    let minSubjAvg = 999;
    let lowestSubject = "—";

    SUBJECTS.forEach((subj) => {
      const { sum, count } = subjTotals[subj];
      if (count > 0) {
        const avg = sum / count;
        if (avg > maxSubjAvg) {
          maxSubjAvg = avg;
          bestSubject = subj;
        }
        if (avg < minSubjAvg) {
          minSubjAvg = avg;
          lowestSubject = subj;
        }
      }
    });

    const gradeCounts = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
    performanceData.forEach((p) => {
      if (p.grade.l in gradeCounts) {
        gradeCounts[p.grade.l as keyof typeof gradeCounts]++;
      }
    });

    return {
      total,
      avgCum: fmtAvg(avgCumNum),
      passCount: passList.length,
      passPct,
      femalePassCount: femalePass,
      topStudent,
      bestSubject,
      lowestSubject,
      gradeCounts,
    };
  }, [performanceData]);

  // 3. Filtered and Sorted Performance Data for Display
  const filteredData = useMemo(() => {
    return performanceData
      .filter((p) => {
        // Search filter
        const name = `${p.student.lastName || ""} ${p.student.firstName || ""}`.toLowerCase();
        const code = (p.student.code || "").toLowerCase();
        const latin = (p.student.latinName || "").toLowerCase();
        const search = searchTerm.toLowerCase();
        if (search && !name.includes(search) && !code.includes(search) && !latin.includes(search)) {
          return false;
        }

        // Gender filter
        if (genderFilter !== "all" && p.student.gender !== genderFilter) {
          return false;
        }

        // Grade filter
        if (gradeFilter !== "all") {
          if (gradeFilter === "pass" && p.result !== "ជាប់") return false;
          if (gradeFilter === "fail" && p.result !== "ធ្លាក់") return false;
          if (["A", "B", "C", "D", "E", "F"].includes(gradeFilter) && p.grade.l !== gradeFilter) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        let comp = 0;
        if (sortBy === "rank") comp = a.rank - b.rank;
        else if (sortBy === "cum") comp = b.cumAvg - a.cumAvg;
        else if (sortBy === "s1") comp = (b.s1Avg || 0) - (a.s1Avg || 0);
        else if (sortBy === "s2") comp = (b.s2Avg || 0) - (a.s2Avg || 0);
        else if (sortBy === "name") {
          const nameA = `${a.student.lastName} ${a.student.firstName}`;
          const nameB = `${b.student.lastName} ${b.student.firstName}`;
          comp = nameA.localeCompare(nameB, "km");
        }

        return sortOrder === "asc" ? comp : -comp;
      });
  }, [performanceData, searchTerm, genderFilter, gradeFilter, sortBy, sortOrder]);

  // 4. Print Printable Performance Summary Report
  const handlePrintReport = () => {
    const tName = `${teacher?.title || ""} ${teacher?.fullName || ""}`;
    const school = teacher?.school || "សាលាបឋមសិក្សា";
    const province = teacher?.province || "បន្ទាយមានជ័យ";
    const district = teacher?.district || "ភ្នំស្រុក";

    const rowsHTML = performanceData
      .sort((a, b) => a.rank - b.rank)
      .map((p, idx) => {
        const photo = honorPhotos[p.student.id] || p.student.photoUrl || "";
        const photoTag = photo
          ? `<img src="${photo}" style="width:24px;height:24px;border-radius:50%;object-fit:cover;display:inline-block;vertical-align:middle;margin-right:4px;"/>`
          : "";

        return `
        <tr style="text-align:center;font-size:11px;border-bottom:1px solid #e2e8f0;">
          <td style="padding:5px 4px;font-weight:bold;">${toKhNum(p.rank)}</td>
          <td style="padding:5px 6px;text-align:left;">
            ${photoTag}
            <strong>${p.student.lastName || ""} ${p.student.firstName || ""}</strong>
          </td>
          <td style="padding:5px 4px;">${p.student.gender || "—"}</td>
          <td style="padding:5px 4px;font-weight:600;">${p.s1Avg !== null ? fmtAvg(p.s1Avg) : "—"}</td>
          <td style="padding:5px 4px;font-weight:600;">${p.s2Avg !== null ? fmtAvg(p.s2Avg) : "—"}</td>
          <td style="padding:5px 4px;font-weight:bold;font-size:12px;color:#1e3a5f;background:#f8fafc;">${fmtAvg(p.cumAvg)}</td>
          <td style="padding:5px 4px;font-weight:900;color:${p.grade.c}">${p.grade.l}</td>
          <td style="padding:5px 4px;font-weight:bold;color:${p.result === "ជាប់" ? "#15803d" : "#dc2626"};">${p.result}</td>
        </tr>
      `;
      })
      .join("");

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>សេចក្តីសង្ខេបសមិទ្ធកម្មសិស្ស - ថ្នាក់ទី ${selClass}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Hanuman:wght@400;700;900&display=swap');
          body { font-family: 'Hanuman', serif; padding: 10mm; color: #000; background: #fff; }
          .header { text-align: center; margin-bottom: 12px; }
          .title { font-size: 18px; font-weight: 900; color: #1e3a5f; margin: 6px 0; }
          .sub { font-size: 13px; font-weight: 700; color: #475569; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th { background: #1e3a5f; color: #fff; padding: 6px; font-size: 11px; border: 1px solid #1e3a5f; }
          td { border: 1px solid #cbd5e1; }
          .stats-grid { display: flex; justify-content: space-between; gap: 10px; margin-top: 14px; font-size: 11px; }
          .stat-box { border: 1px solid #94a3b8; padding: 8px; border-radius: 6px; flex: 1; text-align: center; background: #f8fafc; }
          .sig-container { display: flex; justify-content: space-between; margin-top: 30px; font-size: 11px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size:14px;font-weight:900;">ព្រះរាជាណាចក្រកម្ពុជា<br>ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
          <div style="font-size:11px;margin-top:2px;">꧁ ༺ ༻ ꧂</div>
          <div class="title">របាយការណ៍សង្ខេបសមិទ្ធកម្ម និងចំណាត់ថ្នាក់សិស្ស (Performance Summary)</div>
          <div class="sub">${school} · ថ្នាក់ទី ${selClass} · ឆ្នាំសិក្សា ២០២៥-២០២៦</div>
        </div>

        <div class="stats-grid">
          <div class="stat-box"><strong>សិស្សសរុប</strong><br><span style="font-size:14px;font-weight:bold;">${toKhNum(classMetrics.total)} នាក់</span></div>
          <div class="stat-box"><strong>មធ្យមភាគរួមថ្នាក់</strong><br><span style="font-size:14px;font-weight:bold;color:#2563eb;">${toKhNum(classMetrics.avgCum)}</span></div>
          <div class="stat-box"><strong>អត្រាសិស្សជាប់</strong><br><span style="font-size:14px;font-weight:bold;color:#16a34a;">${toKhNum(classMetrics.passPct)}% (${toKhNum(classMetrics.passCount)} នាក់)</span></div>
          <div class="stat-box"><strong>សិស្សឆ្នើមលេខ១</strong><br><span style="font-size:13px;font-weight:bold;color:#b45309;">${classMetrics.topStudent ? `${classMetrics.topStudent.student.lastName} ${classMetrics.topStudent.student.firstName}` : "—"}</span></div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width:7%;">ចំណាត់ថ្នាក់</th>
              <th style="width:28%;">គោត្តនាម និងនាមសិស្ស</th>
              <th style="width:8%;">ភេទ</th>
              <th style="width:12%;">ម.ភាគ ឆមាស១</th>
              <th style="width:12%;">ម.ភាគ ឆមាស២</th>
              <th style="width:13%;">ម.ភាគរួមឆ្នាំ</th>
              <th style="width:10%;">និទ្ទេស</th>
              <th style="width:10%;">លទ្ធផល</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML}
          </tbody>
        </table>

        <div class="sig-container">
          <div style="text-align:center;width:40%;">
            <div>បានឃើញ និងឯកភាព</div>
            <div style="font-weight:bold;margin-top:2px;">នាយក/នាយិកាសាលា</div>
            <div style="margin-top:45px;">................................................</div>
          </div>
          <div style="text-align:center;width:45%;">
            <div>ថ្ងៃ............ ខែ............ ឆ្នាំ............ ព.ស. ២៥៧០</div>
            <div>${district}, ថ្ងៃទី............ ខែ............ គ.ស. ២០២៦</div>
            <div style="font-weight:bold;margin-top:2px;">គ្រូបន្ទុកថ្នាក់</div>
            <div style="margin-top:40px;font-weight:bold;">${tName}</div>
          </div>
        </div>
      </body>
      </html>
    `;

    printHTML(html);
  };

  // 5. Export to CSV
  const handleExportCSV = () => {
    const headers = [
      "Rank",
      "Student ID",
      "Last Name",
      "First Name",
      "Gender",
      "S1 Avg",
      "S2 Avg",
      "Cumulative Avg",
      "Grade",
      "Result",
      ...SUBJECTS,
    ];

    const csvRows = [headers.join(",")];

    performanceData
      .sort((a, b) => a.rank - b.rank)
      .forEach((p) => {
        const row = [
          p.rank,
          `"${p.student.code || p.student.id}"`,
          `"${p.student.lastName}"`,
          `"${p.student.firstName}"`,
          `"${p.student.gender}"`,
          p.s1Avg !== null ? p.s1Avg : "",
          p.s2Avg !== null ? p.s2Avg : "",
          p.cumAvg,
          `"${p.grade.l}"`,
          `"${p.result}"`,
          ...SUBJECTS.map((s) => (p.subjectAvgs[s] !== null ? p.subjectAvgs[s] : "")),
        ];
        csvRows.push(row.join(","));
      });

    const csvString = csvRows.join("\n");
    const blob = new Blob(["\uFEFF" + csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Performance_Summary_Class_${selClass}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 text-slate-800 dark:text-slate-100">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-4 sm:p-6 shadow-xl border border-blue-800/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1">
              📈 របាយការណ៍សមិទ្ធកម្មរួម
            </span>
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/40 px-2.5 py-0.5 rounded-full text-xs font-bold">
              ថ្នាក់ទី {selClass}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
            សេចក្តីសង្ខេបសមិទ្ធកម្ម & ចំណាត់ថ្នាក់សិស្ស (Performance Summary)
          </h2>
          <p className="text-xs text-blue-200/80 font-medium">
            ការគណនា និងវាយតម្លៃចំណាត់ថ្នាក់តាមមធ្យមភាគសរុបគ្របដណ្តប់គ្រប់ឆមាស និងមុខវិជ្ជា
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            onClick={handleExportCSV}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            📥 ទាញយក CSV
          </button>
          <button
            onClick={handlePrintReport}
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs px-4 py-2 rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            🖨️ បោះពុម្ពរបាយការណ៍
          </button>
        </div>
      </div>

      {/* Class Statistics Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Card 1: Total Students */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            👥 សិស្សសរុប
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <span className="text-xl font-black text-slate-900 dark:text-white">
              {toKhNum(classMetrics.total)} <span className="text-xs font-normal">នាក់</span>
            </span>
          </div>
        </div>

        {/* Card 2: Cumulative Average */}
        <div className="bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-900/50 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-blue-600 dark:text-blue-400">
            📊 មធ្យមភាគរួមថ្នាក់
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <span className="text-xl font-black text-blue-700 dark:text-blue-300">
              {toKhNum(classMetrics.avgCum)}
            </span>
            <span className="text-[10px] font-bold text-blue-500 bg-blue-50 dark:bg-blue-950/60 px-1.5 py-0.5 rounded">
              / ១០
            </span>
          </div>
        </div>

        {/* Card 3: Pass Rate */}
        <div className="bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/50 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
            ✅ អត្រាសិស្សជាប់
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">
              {toKhNum(classMetrics.passPct)}%
            </span>
            <span className="text-[10px] text-slate-500 font-semibold">
              ({toKhNum(classMetrics.passCount)}/{toKhNum(classMetrics.total)})
            </span>
          </div>
        </div>

        {/* Card 4: Top Student */}
        <div className="bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/50 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
            🥇 សិស្សឆ្នើមលេខ១
          </div>
          <div className="mt-1 truncate font-black text-xs text-amber-800 dark:text-amber-200">
            {classMetrics.topStudent
              ? `${classMetrics.topStudent.student.lastName} ${classMetrics.topStudent.student.firstName}`
              : "—"}
          </div>
        </div>

        {/* Card 5: Best Subject */}
        <div className="bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-900/50 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400">
            ⭐ មុខវិជ្ជាខ្លាំងជាងគេ
          </div>
          <div className="mt-1 truncate font-bold text-xs text-indigo-900 dark:text-indigo-200">
            {classMetrics.bestSubject}
          </div>
        </div>

        {/* Card 6: Area to Improve */}
        <div className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/50 rounded-xl p-3 shadow-sm flex flex-col justify-between">
          <div className="text-[11px] font-bold text-rose-600 dark:text-rose-400">
            🎯 មុខវិជ្ជាត្រូវពង្រឹង
          </div>
          <div className="mt-1 truncate font-bold text-xs text-rose-900 dark:text-rose-200">
            {classMetrics.lowestSubject}
          </div>
        </div>
      </div>

      {/* Navigation Tabs and Controls Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          {/* Internal View Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            <button
              onClick={() => setActiveTab("ranking")}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === "ranking"
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              🏆 បញ្ជីចំណាត់ថ្នាក់ទូទៅ
            </button>

            <button
              onClick={() => setActiveTab("matrix")}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === "matrix"
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              📊 ម៉ាទ្រីសពិន្ទុតតាមមុខវិជ្ជា
            </button>

            <button
              onClick={() => setActiveTab("top5")}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === "top5"
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              🥇 សិស្សពូកែកំពូល ៥
            </button>

            <button
              onClick={() => setActiveTab("analytics")}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === "analytics"
                  ? "bg-blue-600 text-white shadow-sm"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              📈 វិភាគសមិទ្ធកម្ម
            </button>
          </div>

          {/* Value Display Mode Switch (Numerical Average vs Grade Letter A-F) */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-bold text-slate-500">ការបង្ហាញ:</span>
            <div className="bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center text-xs font-bold">
              <button
                onClick={() => setDisplayMode("avg")}
                className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                  displayMode === "avg"
                    ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-2xs"
                    : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                123 ពិន្ទុ
              </button>
              <button
                onClick={() => setDisplayMode("grade")}
                className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                  displayMode === "grade"
                    ? "bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-2xs"
                    : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                A-F និទ្ទេស
              </button>
            </div>
          </div>
        </div>

        {/* Search, Filters and Sort Options */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 text-xs">
          {/* Search Bar */}
          <div className="relative flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="🔍 ស្វែងរកឈ្មោះ ឬអត្តលេខសិស្ស..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Gender Filter */}
            <select
              value={genderFilter}
              onChange={(e) => setGenderFilter(e.target.value as any)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-bold text-xs cursor-pointer"
            >
              <option value="all">🚻 គ្រប់ភេទ</option>
              <option value="ប្រុស">👨 ប្រុស</option>
              <option value="ស្រី">👩 ស្រី</option>
            </select>

            {/* Grade Filter */}
            <select
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-bold text-xs cursor-pointer"
            >
              <option value="all">🎯 គ្រប់និទ្ទេស</option>
              <option value="A">⭐ និទ្ទេស A</option>
              <option value="B">📘 និទ្ទេស B</option>
              <option value="C">📙 និទ្ទេស C</option>
              <option value="D">📗 និទ្ទេស D</option>
              <option value="E">📕 និទ្ទេស E</option>
              <option value="F">🖤 និទ្ទេស F</option>
              <option value="pass">✅ ជាប់</option>
              <option value="fail">❌ ធ្លាក់</option>
            </select>

            {/* Sort Field */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-bold text-xs cursor-pointer"
            >
              <option value="rank">🥇 តម្រៀបតាមចំណាត់ថ្នាក់</option>
              <option value="cum">📊 តម្រៀបតាមម.ភាគរួមឆ្នាំ</option>
              <option value="s1">📚 តម្រៀបតាមម.ភាគឆមាស១</option>
              <option value="s2">📚 តម្រៀបតាមម.ភាគឆមាស២</option>
              <option value="name">🔤 តម្រៀបតាមឈ្មោះ A-Z</option>
            </select>

            {/* Sort Order Toggle */}
            <button
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 font-extrabold px-2.5 py-1.5 rounded-lg text-xs cursor-pointer"
              title="ប្តូរទិសដៅតម្រៀប"
            >
              {sortOrder === "asc" ? "⬆️ ឡើង" : "⬇️ ចុះ"}
            </button>
          </div>
        </div>
      </div>

      {/* Main Tab Content Display */}

      {/* 1. OVERALL RANKING TABLE VIEW */}
      {activeTab === "ranking" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-extrabold uppercase text-[11px] tracking-wider border-b border-slate-800">
                  <th className="py-3 px-3 text-center w-14">ថ្នាក់</th>
                  <th className="py-3 px-4">សិស្ស</th>
                  <th className="py-3 px-3 text-center w-16">ភេទ</th>
                  <th className="py-3 px-3 text-center">ម.ភាគ ឆមាស១</th>
                  <th className="py-3 px-3 text-center">ម.ភាគ ឆមាស២</th>
                  <th className="py-3 px-3 text-center">និន្នាការ</th>
                  <th className="py-3 px-4 text-center bg-blue-950/80 text-blue-200">
                    មធ្យមភាគរួមឆ្នាំ
                  </th>
                  <th className="py-3 px-3 text-center w-20">និទ្ទេស</th>
                  <th className="py-3 px-3 text-center w-20">លទ្ធផល</th>
                  <th className="py-3 px-3 text-center w-16">សកម្មភាព</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80 font-medium">
                {filteredData.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="text-center py-12 text-slate-400">
                      <div className="text-2xl mb-1">🔍</div>
                      <p className="font-semibold text-xs">មិនមានទិន្នន័យត្រូវតាមការស្វែងរកឡើយ</p>
                    </td>
                  </tr>
                ) : (
                  filteredData.map((item) => {
                    const photo = honorPhotos[item.student.id] || item.student.photoUrl;
                    const isTop3 = item.rank <= 3;
                    const medal =
                      item.rank === 1 ? "🥇" : item.rank === 2 ? "🥈" : item.rank === 3 ? "🥉" : "";

                    return (
                      <tr
                        key={item.student.id}
                        onClick={() => setSelectedStudent(item)}
                        className={`hover:bg-blue-50/60 dark:hover:bg-slate-800/60 transition cursor-pointer ${
                          item.rank === 1
                            ? "bg-amber-50/40 dark:bg-amber-950/20"
                            : item.rank === 2
                            ? "bg-slate-50/80 dark:bg-slate-800/30"
                            : item.rank === 3
                            ? "bg-orange-50/30 dark:bg-orange-950/20"
                            : ""
                        }`}
                      >
                        {/* Rank Badge */}
                        <td className="py-2.5 px-3 text-center font-black">
                          <span
                            className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-black ${
                              item.rank === 1
                                ? "bg-amber-400 text-slate-950 shadow-xs"
                                : item.rank === 2
                                ? "bg-slate-300 text-slate-900"
                                : item.rank === 3
                                ? "bg-amber-700 text-white"
                                : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                            }`}
                          >
                            {medal || toKhNum(item.rank)}
                          </span>
                        </td>

                        {/* Student Name and Photo */}
                        <td className="py-2.5 px-4 font-bold text-slate-900 dark:text-white">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden shrink-0 border border-slate-300 dark:border-slate-600 flex items-center justify-center text-xs">
                              {photo ? (
                                <img
                                  src={photo}
                                  alt={item.student.firstName}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span>{item.student.gender === "ស្រី" ? "👩" : "👨"}</span>
                              )}
                            </div>
                            <div>
                              <div className="font-extrabold text-xs">
                                {item.student.lastName} {item.student.firstName}
                              </div>
                              {item.student.code && (
                                <div className="text-[10px] text-slate-400 font-normal">
                                  ID: {item.student.code}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Gender */}
                        <td className="py-2.5 px-3 text-center font-bold">
                          <span
                            className={
                              item.student.gender === "ស្រី"
                                ? "text-pink-600 dark:text-pink-400"
                                : "text-blue-600 dark:text-blue-400"
                            }
                          >
                            {item.student.gender}
                          </span>
                        </td>

                        {/* S1 Avg */}
                        <td className="py-2.5 px-3 text-center font-semibold text-slate-700 dark:text-slate-300">
                          {displayMode === "avg"
                            ? item.s1Avg !== null
                              ? fmtAvg(item.s1Avg)
                              : "—"
                            : item.s1Avg !== null
                            ? gradeOf(item.s1Avg).l
                            : "—"}
                        </td>

                        {/* S2 Avg */}
                        <td className="py-2.5 px-3 text-center font-semibold text-slate-700 dark:text-slate-300">
                          {displayMode === "avg"
                            ? item.s2Avg !== null
                              ? fmtAvg(item.s2Avg)
                              : "—"
                            : item.s2Avg !== null
                            ? gradeOf(item.s2Avg).l
                            : "—"}
                        </td>

                        {/* Trend Indicator */}
                        <td className="py-2.5 px-3 text-center">
                          {item.trend === "up" && (
                            <span
                              className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded-full"
                              title={`កើនឡើង +${item.trendDiff}`}
                            >
                              📈 +{fmtAvg(item.trendDiff)}
                            </span>
                          )}
                          {item.trend === "down" && (
                            <span
                              className="text-[10px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded-full"
                              title={`ថយចុះ ${item.trendDiff}`}
                            >
                              📉 {fmtAvg(item.trendDiff)}
                            </span>
                          )}
                          {item.trend === "neutral" && (
                            <span className="text-[10px] text-slate-400 font-bold">➡️ ថេរ</span>
                          )}
                          {item.trend === "none" && (
                            <span className="text-[10px] text-slate-300">—</span>
                          )}
                        </td>

                        {/* Cumulative Overall Average */}
                        <td className="py-2.5 px-4 text-center font-black text-sm text-blue-700 dark:text-blue-300 bg-blue-50/50 dark:bg-blue-950/20">
                          {displayMode === "avg" ? fmtAvg(item.cumAvg) : item.grade.l}
                        </td>

                        {/* Grade */}
                        <td className="py-2.5 px-3 text-center font-black">
                          <span
                            className="inline-block px-2 py-0.5 rounded text-white text-xs font-black shadow-2xs"
                            style={{ backgroundColor: item.grade.c }}
                          >
                            {item.grade.l}
                          </span>
                        </td>

                        {/* Pass/Fail Status */}
                        <td className="py-2.5 px-3 text-center font-bold">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              item.result === "ជាប់"
                                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300"
                                : "bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300"
                            }`}
                          >
                            {item.result}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-2.5 px-3 text-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedStudent(item);
                            }}
                            className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 p-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                            title="មើលព័ត៌មានលម្អិត"
                          >
                            👁️
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. SUBJECT PERFORMANCE MATRIX VIEW */}
      {activeTab === "matrix" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs font-bold">
            <span>📊 ម៉ាទ្រីសពិន្ទុតាមមុខវិជ្ជានីមួយៗ (Cumulative Subject Averages)</span>
            <span className="text-slate-500 font-normal">
              បៃតង = ≥៨.០ · ក្រហម = &lt;៥.០
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-extrabold text-[10px] border-b border-slate-800">
                  <th className="py-2.5 px-2 text-center w-10 sticky left-0 bg-slate-900 z-10">
                    #
                  </th>
                  <th className="py-2.5 px-3 sticky left-10 bg-slate-900 z-10 min-w-[130px]">
                    ឈ្មោះសិស្ស
                  </th>
                  {SUBJECTS.map((subj) => (
                    <th
                      key={subj}
                      className="py-2.5 px-2 text-center font-bold truncate max-w-[80px]"
                      title={subj}
                    >
                      {subj}
                    </th>
                  ))}
                  <th className="py-2.5 px-3 text-center bg-blue-950 text-blue-200 font-black">
                    ម.ភាគរួម
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
                {filteredData.map((p) => (
                  <tr
                    key={p.student.id}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition"
                  >
                    <td className="py-2 px-2 text-center font-bold text-slate-500 sticky left-0 bg-white dark:bg-slate-900 z-10">
                      {p.rank}
                    </td>
                    <td className="py-2 px-3 font-extrabold text-slate-900 dark:text-white sticky left-10 bg-white dark:bg-slate-900 z-10 shadow-r">
                      {p.student.lastName} {p.student.firstName}
                    </td>

                    {SUBJECTS.map((subj) => {
                      const avg = p.subjectAvgs[subj];
                      const isHigh = avg !== null && avg >= 8.0;
                      const isLow = avg !== null && avg < 5.0;

                      return (
                        <td
                          key={subj}
                          className={`py-2 px-2 text-center font-bold ${
                            isHigh
                              ? "text-emerald-600 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/20"
                              : isLow
                              ? "text-rose-600 dark:text-rose-400 bg-rose-50/50 dark:bg-rose-950/20"
                              : "text-slate-700 dark:text-slate-300"
                          }`}
                        >
                          {avg !== null ? (displayMode === "avg" ? fmtAvg(avg) : gradeOf(avg).l) : "—"}
                        </td>
                      );
                    })}

                    <td className="py-2 px-3 text-center font-black text-blue-700 dark:text-blue-300 bg-blue-50/60 dark:bg-blue-950/30">
                      {fmtAvg(p.cumAvg)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. TOP 5 HONOR CARDS VIEW */}
      {activeTab === "top5" && (
        <div className="space-y-4">
          <div className="text-center space-y-1">
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              🏆 តារាងកិត្តិយសសិស្សពូកែកំពូល ៥ ច្រើនជាងគេប្រចាំឆ្នាំ
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              សិស្សដែលមានមធ្យមភាគផលបូកខ្ពស់ជាងគេបំផុតក្នុងថ្នាក់ទី {selClass}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {performanceData
              .sort((a, b) => a.rank - b.rank)
              .slice(0, 5)
              .map((p) => {
                const photo = honorPhotos[p.student.id] || p.student.photoUrl;
                const badge =
                  p.rank === 1
                    ? "🥇 លេខ ១"
                    : p.rank === 2
                    ? "🥈 លេខ ២"
                    : p.rank === 3
                    ? "🥉 លេខ ៣"
                    : p.rank === 4
                    ? "④ លេខ ៤"
                    : "⑤ លេខ ៥";

                const borderC =
                  p.rank === 1
                    ? "border-amber-400 bg-gradient-to-b from-amber-50 to-white dark:from-amber-950/30 dark:to-slate-900"
                    : p.rank === 2
                    ? "border-slate-300 bg-gradient-to-b from-slate-50 to-white dark:from-slate-800/40 dark:to-slate-900"
                    : p.rank === 3
                    ? "border-amber-700/60 bg-gradient-to-b from-orange-50 to-white dark:from-amber-900/20 dark:to-slate-900"
                    : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900";

                return (
                  <div
                    key={p.student.id}
                    onClick={() => setSelectedStudent(p)}
                    className={`rounded-2xl border-2 p-4 text-center shadow-lg relative flex flex-col items-center justify-between transition hover:-translate-y-1 cursor-pointer ${borderC}`}
                  >
                    <div className="bg-slate-900 text-white font-black text-xs px-3 py-1 rounded-full shadow-md mb-3">
                      {badge}
                    </div>

                    <div className="w-20 h-20 rounded-full border-4 border-amber-400/80 overflow-hidden shadow-md mb-3 bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-2xl">
                      {photo ? (
                        <img
                          src={photo}
                          alt={p.student.firstName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span>{p.student.gender === "ស្រី" ? "👩" : "👨"}</span>
                      )}
                    </div>

                    <div className="space-y-1 w-full">
                      <div className="font-black text-sm text-slate-900 dark:text-white truncate">
                        {p.student.lastName} {p.student.firstName}
                      </div>
                      <div className="text-[11px] text-slate-500 font-semibold">
                        ភេទ: {p.student.gender}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200/80 dark:border-slate-800 w-full space-y-1">
                      <div className="text-[10px] uppercase font-bold text-slate-400">
                        មធ្យមភាគសរុប
                      </div>
                      <div className="text-2xl font-black text-blue-700 dark:text-blue-300">
                        {fmtAvg(p.cumAvg)}
                      </div>
                      <div
                        className="inline-block px-2.5 py-0.5 rounded text-white text-xs font-extrabold"
                        style={{ backgroundColor: p.grade.c }}
                      >
                        និទ្ទេស {p.grade.l}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* 4. PERFORMANCE ANALYTICS & DISTRIBUTION VIEW */}
      {activeTab === "analytics" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Grade Distribution Bar Chart */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
            <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
              📊 ការបែងចែកនិទ្ទេសក្នុងថ្នាក់ (Grade Distribution)
            </h4>
            <div className="space-y-2 pt-2">
              {[
                { label: "A (៩.៥-១០)", key: "A", color: "#15803d" },
                { label: "B (៨.០-៩.៤)", key: "B", color: "#1d4ed8" },
                { label: "C (៧.០-៧.៩)", key: "C", color: "#b45309" },
                { label: "D (៦.៥-៦.៩)", key: "D", color: "#c2410c" },
                { label: "E (៥.០-៦.៤)", key: "E", color: "#dc2626" },
                { label: "F (<៥.០)", key: "F", color: "#7f1d1d" },
              ].map((item) => {
                const count = classMetrics.gradeCounts[item.key as keyof typeof classMetrics.gradeCounts];
                const pct = classMetrics.total > 0 ? Math.round((count / classMetrics.total) * 100) : 0;

                return (
                  <div key={item.key} className="space-y-1">
                    <div className="flex justify-between text-xs font-bold">
                      <span style={{ color: item.color }}>{item.label}</span>
                      <span>
                        {toKhNum(count)} នាក់ ({toKhNum(pct)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${pct}%`, backgroundColor: item.color }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pass vs Fail & Gender Performance */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-4">
            <h4 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-2">
              ⚖️ លទ្ធផលជាប់/ធ្លាក់ និងសមិទ្ធកម្មតាមភេទ
            </h4>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl p-3 text-center space-y-1">
                <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                  ✅ ប្រឡងជាប់សរុប
                </div>
                <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                  {toKhNum(classMetrics.passCount)} នាក់
                </div>
                <div className="text-[11px] font-bold text-emerald-700/80">
                  ស្មើនឹង {toKhNum(classMetrics.passPct)}% នៃថ្នាក់
                </div>
              </div>

              <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl p-3 text-center space-y-1">
                <div className="text-xs font-bold text-rose-800 dark:text-rose-300">
                  ❌ ប្រឡងធ្លាក់សរុប
                </div>
                <div className="text-2xl font-black text-rose-600 dark:text-rose-400">
                  {toKhNum(classMetrics.total - classMetrics.passCount)} នាក់
                </div>
                <div className="text-[11px] font-bold text-rose-700/80">
                  ស្មើនឹង {toKhNum(100 - classMetrics.passPct)}% នៃថ្នាក់
                </div>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 space-y-2 text-xs">
              <div className="font-bold text-slate-700 dark:text-slate-300">
                👩 សិស្សស្រីប្រឡងជាប់: <strong className="text-pink-600">{toKhNum(classMetrics.femalePassCount)} នាក់</strong>
              </div>
              <div className="font-bold text-slate-700 dark:text-slate-300">
                👨 សិស្សប្រុសប្រឡងជាប់: <strong className="text-blue-600">{toKhNum(classMetrics.passCount - classMetrics.femalePassCount)} នាក់</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. INDIVIDUAL STUDENT DETAIL MODAL */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden border-2 border-blue-500 shrink-0 flex items-center justify-center text-lg">
                  {honorPhotos[selectedStudent.student.id] || selectedStudent.student.photoUrl ? (
                    <img
                      src={honorPhotos[selectedStudent.student.id] || selectedStudent.student.photoUrl}
                      alt={selectedStudent.student.firstName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{selectedStudent.student.gender === "ស្រី" ? "👩" : "👨"}</span>
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    {selectedStudent.student.lastName} {selectedStudent.student.firstName}
                  </h3>
                  <p className="text-xs text-slate-500 font-semibold">
                    ភេទ: {selectedStudent.student.gender} · ថ្នាក់ទី {selClass} · ID: {selectedStudent.student.code || selectedStudent.student.id}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedStudent(null)}
                className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Performance Key Badges */}
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-2">
                <div className="text-[10px] font-bold text-amber-700">ចំណាត់ថ្នាក់</div>
                <div className="text-base font-black text-amber-800 dark:text-amber-300">
                  #{toKhNum(selectedStudent.rank)}
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl p-2">
                <div className="text-[10px] font-bold text-blue-700">ម.ភាគរួម</div>
                <div className="text-base font-black text-blue-800 dark:text-blue-300">
                  {fmtAvg(selectedStudent.cumAvg)}
                </div>
              </div>

              <div className="bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-xl p-2">
                <div className="text-[10px] font-bold text-purple-700">និទ្ទេស</div>
                <div
                  className="text-base font-black"
                  style={{ color: selectedStudent.grade.c }}
                >
                  {selectedStudent.grade.l}
                </div>
              </div>

              <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl p-2">
                <div className="text-[10px] font-bold text-emerald-700">លទ្ធផល</div>
                <div
                  className={`text-base font-black ${
                    selectedStudent.result === "ជាប់" ? "text-emerald-600" : "text-rose-600"
                  }`}
                >
                  {selectedStudent.result}
                </div>
              </div>
            </div>

            {/* Semester Comparison */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 space-y-1 text-xs">
              <div className="font-bold text-slate-800 dark:text-slate-200 flex justify-between">
                <span>📚 ឆមាសទី ១: {selectedStudent.s1Avg !== null ? fmtAvg(selectedStudent.s1Avg) : "—"}</span>
                <span>📚 ឆមាសទី ២: {selectedStudent.s2Avg !== null ? fmtAvg(selectedStudent.s2Avg) : "—"}</span>
              </div>
              {selectedStudent.trend !== "none" && (
                <div className="text-[11px] font-semibold text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-700">
                  និន្នាការការសិក្សា:{" "}
                  {selectedStudent.trend === "up" ? (
                    <strong className="text-emerald-600">📈 កើនឡើង (+{fmtAvg(selectedStudent.trendDiff)})</strong>
                  ) : selectedStudent.trend === "down" ? (
                    <strong className="text-rose-600">📉 ថយចុះ ({fmtAvg(selectedStudent.trendDiff)})</strong>
                  ) : (
                    <strong className="text-slate-600">➡️ ថេរ</strong>
                  )}
                </div>
              )}
            </div>

            {/* Subject Breakdown Bars */}
            <div className="space-y-2">
              <h4 className="font-black text-xs text-slate-800 dark:text-slate-200">
                📝 សមិទ្ធកម្មតាមមុខវិជ្ជានីមួយៗ:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {SUBJECTS.map((subj) => {
                  const val = selectedStudent.subjectAvgs[subj];
                  const pct = val !== null ? Math.min(100, Math.max(0, (val / 10) * 100)) : 0;

                  return (
                    <div
                      key={subj}
                      className="bg-slate-50 dark:bg-slate-800/40 p-2 rounded-lg space-y-1 border border-slate-100 dark:border-slate-800"
                    >
                      <div className="flex justify-between font-bold text-[11px]">
                        <span className="truncate">{subj}</span>
                        <span className="text-blue-600 dark:text-blue-400">
                          {val !== null ? fmtAvg(val) : "—"}
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedStudent(null)}
                className="bg-slate-900 text-white font-bold text-xs px-4 py-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
              >
                បិទ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
