import React, { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Student, ScoreMap, TeacherProfile } from "../../types";
import { getAvg, getRank, gradeOf, resultOf, fmtAvg } from "../../lib/constants";

interface QRScannerModalProps {
  isOpen: boolean;
  students: Student[];
  scoresMap: Record<string, ScoreMap>;
  selClass: string;
  schoolName: string;
  teacher?: TeacherProfile | null;
  onClose: () => void;
  onSelectStudent?: (student: Student) => void;
  toast: (msg: string, type?: "success" | "error" | "info") => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({
  isOpen,
  students,
  scoresMap,
  selClass,
  schoolName,
  teacher,
  onClose,
  onSelectStudent,
  toast,
}) => {
  const [scannedResult, setScannedResult] = useState<{
    text: string;
    student?: Student;
    parsedInfo?: Record<string, string>;
  } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [availableCameras, setAvailableCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>("");

  const html5QrcodeRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = "qr-reader-container";

  useEffect(() => {
    if (!isOpen) {
      stopScanner();
      setScannedResult(null);
      setCameraError(null);
      return;
    }

    // Get available camera devices
    Html5Qrcode.getCameras()
      .then((devices) => {
        if (devices && devices.length > 0) {
          setAvailableCameras(devices.map((d) => ({ id: d.id, label: d.label || `Camera ${d.id.substring(0, 4)}` })));
          // Prefer back camera if available
          const backCam = devices.find((d) => d.label.toLowerCase().includes("back") || d.label.toLowerCase().includes("environment"));
          setSelectedCameraId(backCam ? backCam.id : devices[0].id);
        } else {
          setCameraError("រកមិនឃើញកាមេរ៉ាលើឧបករណ៍នេះទេ (No camera detected)");
        }
      })
      .catch((err) => {
        console.warn("Camera permission error:", err);
        setCameraError("សូមអនុញ្ញាតសិទ្ធិប្រើប្រាស់កាមេរ៉ា (Please allow camera permissions)");
      });

    return () => {
      stopScanner();
    };
  }, [isOpen]);

  const startScanner = async (cameraId?: string) => {
    stopScanner();
    setCameraError(null);
    setScannedResult(null);

    const targetCamId = cameraId || selectedCameraId;
    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    try {
      const html5Qrcode = new Html5Qrcode(scannerContainerId);
      html5QrcodeRef.current = html5Qrcode;

      const cameraParam = targetCamId ? { deviceId: { exact: targetCamId } } : { facingMode: "environment" };

      await html5Qrcode.start(
        cameraParam,
        config,
        (decodedText) => {
          handleDecodedResult(decodedText);
        },
        () => {
          // Frame scan error - safe to ignore
        }
      );
      setIsScanning(true);
    } catch (err: any) {
      console.error("Failed to start QR scanner:", err);
      setCameraError(err?.message || "មិនអាចបើកកាមេរ៉ាបានទេ (Failed to start camera)");
      setIsScanning(false);
    }
  };

  const stopScanner = () => {
    if (html5QrcodeRef.current && html5QrcodeRef.current.isScanning) {
      html5QrcodeRef.current
        .stop()
        .then(() => {
          html5QrcodeRef.current?.clear();
          html5QrcodeRef.current = null;
          setIsScanning(false);
        })
        .catch((e) => {
          console.warn("Stop scanner error:", e);
          setIsScanning(false);
        });
    } else {
      setIsScanning(false);
    }
  };

  const handleDecodedResult = (text: string) => {
    // Play subtle audio beep if supported
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.value = 880;
      gain.gain.value = 0.1;
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    } catch {
      // Audio fallback
    }

    stopScanner();

    // Try to locate student in database by ID or code or string parsing
    let matchedStudent: Student | undefined;

    // 1. Check if payload contains student ID or Code
    const matchId = text.match(/ID:\s*([^\s|\n]+)/i);
    const extractedId = matchId ? matchId[1].trim() : "";

    if (extractedId) {
      matchedStudent = students.find((s) => s.id === extractedId || s.code === extractedId);
    }

    if (!matchedStudent) {
      // Try searching for student name or id anywhere in payload
      matchedStudent = students.find((s) => {
        if (s.id && text.includes(s.id)) return true;
        if (s.code && text.includes(s.code)) return true;
        const nameKey = `${s.lastName || ""} ${s.firstName || ""}`.trim();
        if (nameKey && text.includes(nameKey)) return true;
        return false;
      });
    }

    // Parse lines into key-value pairs if text format
    const lines = text.split("\n");
    const parsedInfo: Record<string, string> = {};
    lines.forEach((line) => {
      if (line.includes(":")) {
        const [k, ...v] = line.split(":");
        parsedInfo[k.trim()] = v.join(":").trim();
      }
    });

    setScannedResult({
      text,
      student: matchedStudent,
      parsedInfo: Object.keys(parsedInfo).length > 0 ? parsedInfo : undefined,
    });

    if (matchedStudent) {
      toast(`✅ ស្កែនជោគជ័យ! បានរកឃើញសិស្ស ៖ ${matchedStudent.lastName} ${matchedStudent.firstName}`, "success");
    } else {
      toast("ℹ️ បានស្កែន QR Code! សូមពិនិត្យព័ត៌មានខាងក្រោម", "info");
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const html5Qrcode = new Html5Qrcode("qr-file-temp");
    html5Qrcode
      .scanFile(file, true)
      .then((decodedText) => {
        handleDecodedResult(decodedText);
        html5Qrcode.clear();
      })
      .catch((err) => {
        toast("❌ ពុំអាចអាន QR Code ពីរូបភាពនេះបានទេ!", "error");
        console.error("Scan file error:", err);
      });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-800 animate-fade-in relative flex flex-col max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-xl font-bold">
              📷
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white leading-tight">
                ស្កែន QR Code ផ្ទៀងផ្ទាត់សិស្ស
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Camera QR Code Verification Scanner
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopScanner();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-500 font-bold transition"
          >
            ✕
          </button>
        </div>

        {/* Hidden temp container for file scanning */}
        <div id="qr-file-temp" className="hidden"></div>

        {/* Main Content Area */}
        {!scannedResult ? (
          <div className="space-y-4">
            {/* Camera View Area */}
            <div className="relative rounded-2xl overflow-hidden bg-slate-950 border-2 border-dashed border-emerald-500/50 min-h-[280px] flex items-center justify-center">
              <div id={scannerContainerId} className="w-full h-full min-h-[280px]"></div>

              {!isScanning && !cameraError && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-900/90 text-white z-10 space-y-3">
                  <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl animate-pulse">
                    📷
                  </div>
                  <h4 className="font-bold text-sm">ចុចប៊ូតុងខាងក្រោមដើម្បីចាប់ផ្ដើមបើកកាមេរ៉ា</h4>
                  <p className="text-xs text-slate-400 max-w-xs">
                    តំរង់កាមេរ៉ាទូរស័ព្ទ ឬកុំព្យូទ័រទៅលើ QR Code ដែលមាននៅលើសលាកបត្រ ឬវិញ្ញាបនបត្រសិស្ស
                  </p>
                  <button
                    onClick={() => startScanner()}
                    className="mt-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs px-6 py-2.5 rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer"
                  >
                    <span>▶️</span> បើកកាមេរ៉ាស្កែន
                  </button>
                </div>
              )}

              {cameraError && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-900/95 text-white z-10 space-y-3">
                  <div className="text-3xl">⚠️</div>
                  <h4 className="font-bold text-sm text-amber-400">{cameraError}</h4>
                  <p className="text-xs text-slate-400">
                    សូមអនុញ្ញាត Camera Permission ក្នុង Browser ឬប្រើប្រាស់ជម្រើសជ្រើសរើសរូបភាព QR Code ខាងក្រោម
                  </p>
                  <button
                    onClick={() => startScanner()}
                    className="bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs px-4 py-2 rounded-xl transition"
                  >
                    🔄 ព្យាយាមម្ដងទៀត
                  </button>
                </div>
              )}
            </div>

            {/* Controls bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              {availableCameras.length > 1 && (
                <select
                  value={selectedCameraId}
                  onChange={(e) => {
                    setSelectedCameraId(e.target.value);
                    if (isScanning) startScanner(e.target.value);
                  }}
                  className="text-xs bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 font-medium"
                >
                  {availableCameras.map((cam) => (
                    <option key={cam.id} value={cam.id}>
                      📷 {cam.label}
                    </option>
                  ))}
                </select>
              )}

              {isScanning && (
                <button
                  onClick={stopScanner}
                  className="text-xs bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-300 font-bold px-4 py-2 rounded-xl hover:bg-red-200 transition"
                >
                  ⏹️ បិទកាមេរ៉ា
                </button>
              )}

              {/* Upload image file fallback */}
              <label className="text-xs bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 font-bold px-4 py-2 rounded-xl hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition cursor-pointer flex items-center gap-1.5 ml-auto">
                <span>🖼️</span> ជ្រើសរូបភាព QR
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        ) : (
          /* Scanned Result View */
          <div className="space-y-4 animate-fade-in">
            {scannedResult.student ? (
              /* Verified Student Found in Database */
              <div className="bg-emerald-50 dark:bg-emerald-950/50 border-2 border-emerald-500 rounded-2xl p-4 text-slate-800 dark:text-slate-100 space-y-3">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-black text-sm">
                  <span className="text-xl">✅</span>
                  <span>ព័ត៌មានផ្ទៀងផ្ទាត់ត្រឹមត្រូវ (Verified Student)</span>
                </div>

                {(() => {
                  const s = scannedResult.student!;
                  const annualAvg = getAvg(s.id, students, scoresMap);
                  const avgVal = annualAvg !== null ? Number(fmtAvg(annualAvg)) : null;
                  const grade = avgVal !== null ? gradeOf(avgVal) : { l: "—", c: "#6b7280" };
                  const rank = getRank(s.id, students, scoresMap);
                  const resultText = avgVal !== null ? resultOf(avgVal) : "—";

                  const village = s.village || "រោគ";
                  const commune = s.commune || "ស្ពានស្រែង";
                  const district = s.district || "ភ្នំស្រុក";
                  const province = s.province || "បន្ទាយមានជ័យ";
                  const address = `ភូមិ${village}, ឃុំ${commune}, ស្រុក${district}, ខេត្ត${province}`;

                  const teacherName = teacher ? `${teacher.title || ""} ${teacher.fullName || ""}`.trim() : "—";
                  const teacherPhone = teacher?.phone || "";
                  const studentPhone = s.phone || "";
                  const phoneStr = [teacherPhone ? `គ្រូ: ${teacherPhone}` : "", studentPhone ? `សិស្ស: ${studentPhone}` : ""].filter(Boolean).join(" | ") || "—";
                  const gmailStr = teacher?.email || "—";

                  return (
                    <div className="bg-white dark:bg-slate-900 rounded-xl p-3 text-xs space-y-1.5 border border-emerald-200 dark:border-emerald-800/60">
                      <div>
                        <strong>ឈ្មោះសិស្ស ៖</strong> {s.lastName} {s.firstName} ({s.gender || "—"})
                      </div>
                      <div>
                        <strong>អត្តលេខ ៖</strong> {s.code || s.id}
                      </div>
                      <div>
                        <strong>ថ្ងៃកំណើត ៖</strong> {s.dob || "—"}
                      </div>
                      <div>
                        <strong>អាសយដ្ឋាន ៖</strong> {address}
                      </div>
                      {(s.fatherName || s.fatherJob) && (
                        <div>
                          <strong>ឪពុក ៖</strong> {s.fatherName || "—"} {s.fatherJob ? `(${s.fatherJob})` : ""}
                        </div>
                      )}
                      {(s.motherName || s.motherJob) && (
                        <div>
                          <strong>ម្ដាយ ៖</strong> {s.motherName || "—"} {s.motherJob ? `(${s.motherJob})` : ""}
                        </div>
                      )}
                      <div>
                        <strong>ថ្នាក់ទី ៖</strong> {selClass} · {schoolName}
                      </div>
                      <div>
                        <strong>គ្រូបន្ទុកថ្នាក់ ៖</strong> {teacherName}
                      </div>
                      <div>
                        <strong>លេខទូរស័ព្ទ ៖</strong> {phoneStr}
                      </div>
                      <div>
                        <strong>Gmail / Email ៖</strong> {gmailStr}
                      </div>
                      <div className="border-t border-dashed border-emerald-200 dark:border-emerald-800 my-2 pt-2 flex flex-wrap gap-2">
                        <span>
                          <strong>មធ្យមភាគ ៖</strong> {avgVal !== null ? avgVal : "—"}
                        </span>
                        <span>|</span>
                        <span>
                          <strong>និទ្ទេស ៖</strong>{" "}
                          <span className="font-black" style={{ color: grade.c }}>
                            {grade.l}
                          </span>
                        </span>
                        <span>|</span>
                        <span>
                          <strong>ចំណាត់ថ្នាក់ ៖</strong> #{rank !== null ? rank : "—"}
                        </span>
                      </div>
                      <div>
                        <strong>លទ្ធផល ៖</strong>{" "}
                        <span className={`font-black ${resultText === "ជាប់" ? "text-emerald-600" : "text-red-500"}`}>
                          {resultText}
                        </span>
                      </div>
                    </div>
                  );
                })()}

                {onSelectStudent && (
                  <button
                    onClick={() => {
                      onSelectStudent(scannedResult.student!);
                      onClose();
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 rounded-xl transition"
                  >
                    🔍 មើលរបាយការណ៍សិស្សនេះ
                  </button>
                )}
              </div>
            ) : (
              /* Scanned text content displayed cleanly */
              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-xs space-y-3">
                <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
                  <span>📄</span>
                  <span>ព័ត៌មានដែលបានស្កែនពី QR Code (Scanned Payload)</span>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-mono whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">
                  {scannedResult.text}
                </div>
              </div>
            )}

            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => {
                  setScannedResult(null);
                  startScanner();
                }}
                className="bg-emerald-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-emerald-700 transition"
              >
                🔄 ស្កែនម្ដងទៀត (Scan Again)
              </button>
              <button
                onClick={() => {
                  stopScanner();
                  onClose();
                }}
                className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-slate-300 transition"
              >
                បិទ (Close)
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
