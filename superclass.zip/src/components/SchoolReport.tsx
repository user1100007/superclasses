import React, { useState, useEffect, useMemo } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import { CLASSES, MONTHS, SEMESTERS, gradeOf, fmtAvg, getAvg, getThreeWorkingDates, toKhNum } from "../lib/constants";
import { Student, ScoreMap, TeacherProfile } from "../types";
import { printHTML } from "../lib/printUtils";
import * as XLSX from "xlsx";

interface SchoolReportProps {
  teacher: TeacherProfile | null;
  selClass?: string | null;
  currentStudents?: Student[];
  currentScoresMap?: Record<string, ScoreMap>;
  allMonthsScores?: Record<string, Record<string, ScoreMap>>;
}

interface ClassAnnualStat {
  className: string;
  gradeLevel: string; // "1", "2", "3", "4", "5", "6", "other"
  totalEnrolled: number;
  femaleEnrolled: number;
  passAvgTotal: number;
  passAvgFemale: number;
  failAvgTotal: number;
  failAvgFemale: number;
}

interface ClassGradeStat {
  className: string;
  totalStudents: number;
  femaleStudents: number;
  gradeCounts: { A: number; B: number; C: number; D: number; E: number; F: number };
  femaleGradeCounts: { A: number; B: number; C: number; D: number; E: number; F: number };
  avgScore: number | null;
  loading: boolean;
}

interface AdjustmentRecord {
  retestPassedTotal: number;
  retestPassedFemale: number;
  dropoutTotal: number;
  dropoutFemale: number;
}

export const SchoolReport: React.FC<SchoolReportProps> = ({
  teacher,
  selClass,
  currentStudents,
  currentScoresMap,
  allMonthsScores,
}) => {
  // Main view mode: "annual" (លទ្ធផលសិក្សាដំណាច់ឆ្នាំ A=5+6+7) or "monthly_grades" (ស្ថិតិនិទ្ទេស A-F)
  const [reportMode, setReportMode] = useState<"annual" | "monthly_grades">("annual");

  // Annual Report Settings
  const [groupingMode, setGroupingMode] = useState<"grade" | "class">("grade"); // Group by Grade 1-6 or per Class
  const [useKhmerNums, setUseKhmerNums] = useState<boolean>(false);
  const [isEditingAdjustments, setIsEditingAdjustments] = useState<boolean>(false);

  // Custom adjustments for retest (4) and dropout (7)
  const [adjustments, setAdjustments] = useState<Record<string, AdjustmentRecord>>(() => {
    try {
      const saved = localStorage.getItem("school_report_adjustments_v1");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Monthly Grades Report Settings
  const [semesterId, setSemesterId] = useState<string>("s1");
  const [selMonth, setSelMonth] = useState<number>(3); // Default March / មីនា
  const [sig1Role, setSig1Role] = useState<string>("អ្នករៀបចំរបាយការណ៍");
  const [dateMode, setDateMode] = useState<"auto" | "dots">("auto");

  // Data States
  const [classAnnualStats, setClassAnnualStats] = useState<ClassAnnualStat[]>([]);
  const [classMonthlyStats, setClassMonthlyStats] = useState<ClassGradeStat[]>([]);
  const [loadingAll, setLoadingAll] = useState<boolean>(false);

  const curSem = SEMESTERS.find((s) => s.id === semesterId) || SEMESTERS[0];
  const dates = getThreeWorkingDates(selMonth);
  const isTeacherOrOrganizer = sig1Role === "អ្នករៀបចំរបាយការណ៍" || sig1Role === "គ្រូប្រចាំថ្នាក់";

  // Fetch all classes data from Firestore
  const fetchAllSchoolData = async () => {
    setLoadingAll(true);
    const annStats: ClassAnnualStat[] = [];
    const monStats: ClassGradeStat[] = [];

    for (const cls of CLASSES) {
      try {
        let students: Student[] = [];
        if (cls === selClass && currentStudents && currentStudents.length > 0) {
          students = currentStudents;
        } else {
          const stuSnap = await getDocs(collection(db, "classes", cls, "students"));
          stuSnap.forEach((docSnap) => {
            students.push({ id: docSnap.id, ...docSnap.data() } as Student);
          });
        }

        const gradeLevel = cls.replace(/[^0-9]/g, "") || "other";
        const femaleEnrolled = students.filter((s) => s.gender === "ស្រី").length;
        const totalEnrolled = students.length;

        if (totalEnrolled === 0) {
          annStats.push({
            className: cls,
            gradeLevel,
            totalEnrolled: 0,
            femaleEnrolled: 0,
            passAvgTotal: 0,
            passAvgFemale: 0,
            failAvgTotal: 0,
            failAvgFemale: 0,
          });
          monStats.push({
            className: cls,
            totalStudents: 0,
            femaleStudents: 0,
            gradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
            femaleGradeCounts: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
            avgScore: null,
            loading: false,
          });
          continue;
        }

        // 1. Monthly Score Fetching
        let monthlyScoresMap: Record<string, ScoreMap> = {};
        if (cls === selClass && currentScoresMap) {
          monthlyScoresMap = currentScoresMap;
        } else {
          try {
            const mSnap = await getDocs(
              collection(db, "classes", cls, "semesters", semesterId, "months", String(selMonth), "scores")
            );
            mSnap.forEach((docSnap) => {
              monthlyScoresMap[docSnap.id] = docSnap.data().scores || {};
            });
          } catch (e) {
            console.warn(`Monthly scores fetch failed for ${cls}`, e);
          }
        }

        const counts = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
        const femaleCounts = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
        let sumAvgs = 0;
        let countAvgs = 0;

        students.forEach((s) => {
          const avg = getAvg(s.id, students, monthlyScoresMap);
          if (avg > 0 || Object.keys(monthlyScoresMap[s.id] || {}).length > 0) {
            sumAvgs += avg;
            countAvgs++;
            const g = gradeOf(avg).l as "A" | "B" | "C" | "D" | "E" | "F";
            if (counts[g] !== undefined) {
              counts[g]++;
              if (s.gender === "ស្រី") femaleCounts[g]++;
            }
          }
        });

        monStats.push({
          className: cls,
          totalStudents: totalEnrolled,
          femaleStudents: femaleEnrolled,
          gradeCounts: counts,
          femaleGradeCounts: femaleCounts,
          avgScore: countAvgs > 0 ? sumAvgs / countAvgs : null,
          loading: false,
        });

        // 2. Annual Score Fetching (Check Semester 2 months 8, 7, 6, or Semester 1 months 5, 3)
        let annualScoresMap: Record<string, ScoreMap> = {};
        const fetchMonthScores = async (sem: string, m: number) => {
          try {
            const snap = await getDocs(collection(db, "classes", cls, "semesters", sem, "months", String(m), "scores"));
            const map: Record<string, ScoreMap> = {};
            snap.forEach((d) => (map[d.id] = d.data().scores || {}));
            return map;
          } catch {
            return {};
          }
        };

        const [s2_8, s2_7, s2_6, s1_5] = await Promise.all([
          fetchMonthScores("s2", 8),
          fetchMonthScores("s2", 7),
          fetchMonthScores("s2", 6),
          fetchMonthScores("s1", 5),
        ]);

        annualScoresMap = { ...s1_5, ...s2_6, ...s2_7, ...s2_8 };

        if (cls === selClass) {
          if (allMonthsScores) {
            Object.keys(allMonthsScores).forEach((mKey) => {
              annualScoresMap = { ...annualScoresMap, ...allMonthsScores[mKey] };
            });
          }
          if (currentScoresMap) {
            annualScoresMap = { ...annualScoresMap, ...currentScoresMap };
          }
        }

        let passAvgTotal = 0;
        let passAvgFemale = 0;
        let failAvgTotal = 0;
        let failAvgFemale = 0;

        students.forEach((s) => {
          const avg = getAvg(s.id, students, annualScoresMap);
          const isFemale = s.gender === "ស្រី";
          // If no exam recorded yet, default to pass if enrolled, or evaluate score
          const hasScore = Object.keys(annualScoresMap[s.id] || {}).length > 0;
          const passed = hasScore ? avg >= 5.0 : true; // Default passing if fresh database

          if (passed) {
            passAvgTotal++;
            if (isFemale) passAvgFemale++;
          } else {
            failAvgTotal++;
            if (isFemale) failAvgFemale++;
          }
        });

        annStats.push({
          className: cls,
          gradeLevel,
          totalEnrolled,
          femaleEnrolled,
          passAvgTotal,
          passAvgFemale,
          failAvgTotal,
          failAvgFemale,
        });
      } catch (err) {
        console.warn(`Error processing class ${cls}:`, err);
      }
    }

    setClassAnnualStats(annStats);
    setClassMonthlyStats(monStats);
    setLoadingAll(false);
  };

  useEffect(() => {
    fetchAllSchoolData();
  }, [semesterId, selMonth]);

  // Handle saving adjustments
  const handleAdjustmentChange = (key: string, field: keyof AdjustmentRecord, val: number) => {
    setAdjustments((prev) => {
      const updated = {
        ...prev,
        [key]: {
          retestPassedTotal: prev[key]?.retestPassedTotal || 0,
          retestPassedFemale: prev[key]?.retestPassedFemale || 0,
          dropoutTotal: prev[key]?.dropoutTotal || 0,
          dropoutFemale: prev[key]?.dropoutFemale || 0,
          [field]: Math.max(0, val),
        },
      };
      try {
        localStorage.setItem("school_report_adjustments_v1", JSON.stringify(updated));
      } catch (e) {
        console.error("Failed to save adjustments", e);
      }
      return updated;
    });
  };

  // Compile Annual Report Rows
  const annualRows = useMemo(() => {
    if (groupingMode === "grade") {
      const GRADES = ["1", "2", "3", "4", "5", "6"];
      return GRADES.map((g) => {
        const matchingClasses = classAnnualStats.filter((c) => c.gradeLevel === g);
        const totalEnrolled = matchingClasses.reduce((acc, c) => acc + c.totalEnrolled, 0);
        const femaleEnrolled = matchingClasses.reduce((acc, c) => acc + c.femaleEnrolled, 0);
        const passAvgTotal = matchingClasses.reduce((acc, c) => acc + c.passAvgTotal, 0);
        const passAvgFemale = matchingClasses.reduce((acc, c) => acc + c.passAvgFemale, 0);
        const failAvgTotal = matchingClasses.reduce((acc, c) => acc + c.failAvgTotal, 0);
        const failAvgFemale = matchingClasses.reduce((acc, c) => acc + c.failAvgFemale, 0);

        const adj = adjustments[g] || { retestPassedTotal: 0, retestPassedFemale: 0, dropoutTotal: 0, dropoutFemale: 0 };
        const retestPassedTotal = adj.retestPassedTotal;
        const retestPassedFemale = adj.retestPassedFemale;
        const dropoutTotal = adj.dropoutTotal;
        const dropoutFemale = adj.dropoutFemale;

        // 3: ជាប់មធ្យមភាគ
        const col3_total = passAvgTotal;
        const col3_female = passAvgFemale;

        // 4: ធ្វើតេស្ដជាប់
        const col4_total = retestPassedTotal;
        const col4_female = retestPassedFemale;

        // 5: ជាប់ចុងឆ្នាំ (5 = 3 + 4)
        const col5_total = col3_total + col4_total;
        const col5_female = col3_female + col4_female;

        // 6: សិស្សត្រួតថ្នាក់ (6 = failAvg - retest)
        const col6_total = Math.max(0, failAvgTotal - col4_total);
        const col6_female = Math.max(0, failAvgFemale - col4_female);

        // 7: សិស្សបោះបង់
        const col7_total = dropoutTotal;
        const col7_female = dropoutFemale;

        // B: សិស្សចុងឆ្នាំ (B = 5 + 6)
        const colB_total = col5_total + col6_total;
        const colB_female = col5_female + col6_female;

        // A: សិស្សដំណាច់ឆ្នាំ (A = 5 + 6 + 7 = B + 7)
        const colA_total = colB_total + col7_total;
        const colA_female = colB_female + col7_female;

        return {
          id: g,
          label: g,
          gradeName: `ថ្នាក់ទី ${g}`,
          colA_total,
          colA_female,
          colB_total,
          colB_female,
          col3_total,
          col3_female,
          col4_total,
          col4_female,
          col5_total,
          col5_female,
          col6_total,
          col6_female,
          col7_total,
          col7_female,
        };
      });
    } else {
      // Per Class
      return classAnnualStats.map((c) => {
        const adj = adjustments[c.className] || {
          retestPassedTotal: 0,
          retestPassedFemale: 0,
          dropoutTotal: 0,
          dropoutFemale: 0,
        };
        const retestPassedTotal = adj.retestPassedTotal;
        const retestPassedFemale = adj.retestPassedFemale;
        const dropoutTotal = adj.dropoutTotal;
        const dropoutFemale = adj.dropoutFemale;

        const col3_total = c.passAvgTotal;
        const col3_female = c.passAvgFemale;
        const col4_total = retestPassedTotal;
        const col4_female = retestPassedFemale;
        const col5_total = col3_total + col4_total;
        const col5_female = col3_female + col4_female;
        const col6_total = Math.max(0, c.failAvgTotal - col4_total);
        const col6_female = Math.max(0, c.failAvgFemale - col4_female);
        const col7_total = dropoutTotal;
        const col7_female = dropoutFemale;
        const colB_total = col5_total + col6_total;
        const colB_female = col5_female + col6_female;
        const colA_total = colB_total + col7_total;
        const colA_female = colB_female + col7_female;

        return {
          id: c.className,
          label: c.className,
          gradeName: `ថ្នាក់ ${c.className}`,
          colA_total,
          colA_female,
          colB_total,
          colB_female,
          col3_total,
          col3_female,
          col4_total,
          col4_female,
          col5_total,
          col5_female,
          col6_total,
          col6_female,
          col7_total,
          col7_female,
        };
      });
    }
  }, [classAnnualStats, groupingMode, adjustments]);

  // Annual Totals
  const annualTotal = useMemo(() => {
    return annualRows.reduce(
      (acc, r) => {
        acc.colA_total += r.colA_total;
        acc.colA_female += r.colA_female;
        acc.colB_total += r.colB_total;
        acc.colB_female += r.colB_female;
        acc.col3_total += r.col3_total;
        acc.col3_female += r.col3_female;
        acc.col4_total += r.col4_total;
        acc.col4_female += r.col4_female;
        acc.col5_total += r.col5_total;
        acc.col5_female += r.col5_female;
        acc.col6_total += r.col6_total;
        acc.col6_female += r.col6_female;
        acc.col7_total += r.col7_total;
        acc.col7_female += r.col7_female;
        return acc;
      },
      {
        colA_total: 0,
        colA_female: 0,
        colB_total: 0,
        colB_female: 0,
        col3_total: 0,
        col3_female: 0,
        col4_total: 0,
        col4_female: 0,
        col5_total: 0,
        col5_female: 0,
        col6_total: 0,
        col6_female: 0,
        col7_total: 0,
        col7_female: 0,
      }
    );
  }, [annualRows]);

  // Export to Excel
  const exportAnnualToExcel = () => {
    const wsData: any[][] = [
      ["ព្រះរាជាណាចក្រកម្ពុជា"],
      ["ជាតិ សាសនា ព្រះមហាក្សត្រ"],
      [],
      [`${teacher?.school || "សាលាបឋមសិក្សា"} - របាយការណ៍លទ្ធផលសិក្សាដំណាច់ឆ្នាំ`],
      [],
      [
        "ថ្នាក់ទី",
        "សិស្សដំណាច់ឆ្នាំ",
        "",
        "សិស្សចុងឆ្នាំ",
        "",
        "ជាប់មធ្យមភាគ",
        "",
        "ធ្វើតេស្ដជាប់",
        "",
        "ជាប់ចុងឆ្នាំ",
        "",
        "សិស្សត្រួតថ្នាក់",
        "",
        "សិស្សបោះបង់",
        "",
      ],
      [
        "",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
        "សរុប",
        "ស្រី",
      ],
      [
        "",
        "A=5+6+7",
        "A=5+6+7",
        "B=5+6",
        "B=5+6",
        "3",
        "3",
        "4",
        "4",
        "5=3+4",
        "5=3+4",
        "6",
        "6",
        "7",
        "7",
      ],
    ];

    annualRows.forEach((r) => {
      wsData.push([
        r.label,
        r.colA_total,
        r.colA_female,
        r.colB_total,
        r.colB_female,
        r.col3_total,
        r.col3_female,
        r.col4_total,
        r.col4_female,
        r.col5_total,
        r.col5_female,
        r.col6_total,
        r.col6_female,
        r.col7_total,
        r.col7_female,
      ]);
    });

    wsData.push([
      "សរុប",
      annualTotal.colA_total,
      annualTotal.colA_female,
      annualTotal.colB_total,
      annualTotal.colB_female,
      annualTotal.col3_total,
      annualTotal.col3_female,
      annualTotal.col4_total,
      annualTotal.col4_female,
      annualTotal.col5_total,
      annualTotal.col5_female,
      annualTotal.col6_total,
      annualTotal.col6_female,
      annualTotal.col7_total,
      annualTotal.col7_female,
    ]);

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    ws["!merges"] = [
      { s: { r: 5, c: 0 }, e: { r: 7, c: 0 } }, // ថ្នាក់ទី
      { s: { r: 5, c: 1 }, e: { r: 5, c: 2 } }, // សិស្សដំណាច់ឆ្នាំ
      { s: { r: 5, c: 3 }, e: { r: 5, c: 4 } }, // សិស្សចុងឆ្នាំ
      { s: { r: 5, c: 5 }, e: { r: 5, c: 6 } }, // ជាប់មធ្យមភាគ
      { s: { r: 5, c: 7 }, e: { r: 5, c: 8 } }, // ធ្វើតេស្ដជាប់
      { s: { r: 5, c: 9 }, e: { r: 5, c: 10 } }, // ជាប់ចុងឆ្នាំ
      { s: { r: 5, c: 11 }, e: { r: 5, c: 12 } }, // សិស្សត្រួតថ្នាក់
      { s: { r: 5, c: 13 }, e: { r: 5, c: 14 } }, // សិស្សបោះបង់
    ];

    XLSX.utils.book_append_sheet(wb, ws, "លទ្ធផលដំណាច់ឆ្នាំ");
    XLSX.writeFile(wb, `លទ្ធផលសិក្សាដំណាច់ឆ្នាំ_${teacher?.school || "សាលា"}.xlsx`);
  };

  // Print Annual Report via PrintHTML
  const handlePrintAnnual = () => {
    const tableRowsHtml = annualRows
      .map(
        (r) => `
      <tr>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;background-color:#f8fafc;">${useKhmerNums ? toKhNum(r.label) : r.label}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;">${useKhmerNums ? toKhNum(r.colA_total) : r.colA_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">${useKhmerNums ? toKhNum(r.colA_female) : r.colA_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;">${useKhmerNums ? toKhNum(r.colB_total) : r.colB_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">${useKhmerNums ? toKhNum(r.colB_female) : r.colB_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#1e3a8a;">${useKhmerNums ? toKhNum(r.col3_total) : r.col3_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;color:#1e3a8a;">${useKhmerNums ? toKhNum(r.col3_female) : r.col3_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">${useKhmerNums ? toKhNum(r.col4_total) : r.col4_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">${useKhmerNums ? toKhNum(r.col4_female) : r.col4_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;background-color:#ecfdf5;color:#065f46;">${useKhmerNums ? toKhNum(r.col5_total) : r.col5_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;background-color:#ecfdf5;color:#065f46;">${useKhmerNums ? toKhNum(r.col5_female) : r.col5_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;color:#991b1b;">${useKhmerNums ? toKhNum(r.col6_total) : r.col6_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;color:#991b1b;">${useKhmerNums ? toKhNum(r.col6_female) : r.col6_female}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;color:#b45309;">${useKhmerNums ? toKhNum(r.col7_total) : r.col7_total}</td>
        <td style="border:1px solid #334155;padding:6px 4px;text-align:center;color:#b45309;">${useKhmerNums ? toKhNum(r.col7_female) : r.col7_female}</td>
      </tr>
    `
      )
      .join("");

    const totalRowHtml = `
      <tr style="background-color:#f1f5f9;font-weight:bold;">
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">សរុប</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.colA_total) : annualTotal.colA_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.colA_female) : annualTotal.colA_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.colB_total) : annualTotal.colB_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.colB_female) : annualTotal.colB_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#1e3a8a;">${useKhmerNums ? toKhNum(annualTotal.col3_total) : annualTotal.col3_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#1e3a8a;">${useKhmerNums ? toKhNum(annualTotal.col3_female) : annualTotal.col3_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.col4_total) : annualTotal.col4_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;">${useKhmerNums ? toKhNum(annualTotal.col4_female) : annualTotal.col4_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;background-color:#dcfce7;color:#065f46;">${useKhmerNums ? toKhNum(annualTotal.col5_total) : annualTotal.col5_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;background-color:#dcfce7;color:#065f46;">${useKhmerNums ? toKhNum(annualTotal.col5_female) : annualTotal.col5_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#991b1b;">${useKhmerNums ? toKhNum(annualTotal.col6_total) : annualTotal.col6_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#991b1b;">${useKhmerNums ? toKhNum(annualTotal.col6_female) : annualTotal.col6_female}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#b45309;">${useKhmerNums ? toKhNum(annualTotal.col7_total) : annualTotal.col7_total}</td>
        <td style="border:1px solid #334155;padding:8px 4px;text-align:center;font-weight:900;color:#b45309;">${useKhmerNums ? toKhNum(annualTotal.col7_female) : annualTotal.col7_female}</td>
      </tr>
    `;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8" />
        <title>របាយការណ៍លទ្ធផលសិក្សាដំណាច់ឆ្នាំ</title>
        <style>
          @page { size: A4 landscape; margin: 10mm; }
          body { font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', sans-serif; font-size: 12px; color: #0f172a; margin: 0; padding: 10px; }
          table { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 11px; }
          th, td { border: 1px solid #334155; text-align: center; }
          th { background-color: #f1f5f9; padding: 5px 2px; font-weight: bold; }
          .header-box { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
          .sig-box { display: flex; justify-content: space-between; margin-top: 30px; }
          .sig-col { text-align: center; width: 40%; font-size: 12px; }
        </style>
      </head>
      <body>
        <div style="text-align: center; margin-bottom: 12px;">
          <h2 style="margin: 0; font-size: 15px; font-weight: 900;">ព្រះរាជាណាចក្រកម្ពុជា</h2>
          <h3 style="margin: 0; font-size: 13px; font-weight: 900;">ជាតិ សាសនា ព្រះមហាក្សត្រ</h3>
          <div style="font-size: 11px; color: #b45309; margin-top: 2px;">꧁ ༺ ༻ ꧂</div>
        </div>

        <div class="header-box">
          <div style="font-size: 12px; line-height: 1.5; font-weight: bold;">
            <div>រដ្ឋបាលខេត្ត: ${teacher?.province || "……………………"}</div>
            <div>ការិយាល័យអប់រំ យុវជន និងកីឡា: ${teacher?.district || "……………………"}</div>
            <div>សាលារៀន: ${teacher?.school || "សាលាបឋមសិក្សា"}</div>
          </div>
        </div>

        <h1 style="text-align: center; font-size: 16px; font-weight: 900; margin: 12px 0 6px 0; color: #1e3a8a;">
          លទ្ធផលសិក្សាដំណាច់ឆ្នាំ
        </h1>

        <table border="1" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td rowspan="4" style="width: 50px; font-weight: bold; background-color: #f8fafc;">
                <p style="text-align: center; margin: 0;">ថ្នាក់ទី</p>
              </td>
              <td colspan="14" style="font-weight: bold; background-color: #f1f5f9; padding: 6px 0;">
                <p style="text-align: center; margin: 0; font-size: 13px;">លទ្ធផលសិក្សារបស់សិស្ស</p>
              </td>
            </tr>
            <tr>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">សិស្សដំណាច់ឆ្នាំ</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">សិស្សចុងឆ្នាំ</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">ជាប់មធ្យមភាគ</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">ធ្វើតេស្ដជាប់</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #ecfdf5;"><p style="text-align: center; margin: 0; color: #065f46;">ជាប់ចុងឆ្នាំ</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">សិស្សត្រួតថ្នាក់</p></td>
              <td colspan="2" style="font-weight: bold; background-color: #f8fafc;"><p style="text-align: center; margin: 0;">សិស្សបោះបង់</p></td>
            </tr>
            <tr>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold; background-color: #ecfdf5;"><p style="text-align: center; margin: 0; color: #065f46;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold; background-color: #ecfdf5;"><p style="text-align: center; margin: 0; color: #065f46;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
              <td style="width: 45px; font-weight: bold;"><p style="text-align: center; margin: 0;">សរុប</p></td>
              <td style="width: 40px; font-weight: bold;"><p style="text-align: center; margin: 0;">ស្រី</p></td>
            </tr>
            <tr style="background-color: #f1f5f9; font-size: 10px; font-weight: bold; color: #475569;">
              <td colspan="2"><p style="text-align: center; margin: 0;">A=5+6+7</p></td>
              <td colspan="2"><p style="text-align: center; margin: 0;">B=5+6</p></td>
              <td colspan="2"><p style="text-align: center; margin: 0;">3</p></td>
              <td colspan="2"><p style="text-align: center; margin: 0;">4</p></td>
              <td colspan="2" style="background-color: #dcfce7; color: #065f46;"><p style="text-align: center; margin: 0;">5=3+4</p></td>
              <td colspan="2"><p style="text-align: center; margin: 0;">6</p></td>
              <td colspan="2"><p style="text-align: center; margin: 0;">7</p></td>
            </tr>
            ${tableRowsHtml}
            ${totalRowHtml}
          </tbody>
        </table>

        <div class="sig-box">
          <div class="sig-col">
            <div style="font-weight: bold; font-size: 13px;">បានឃើញ និងឯកភាព</div>
            ${
              isTeacherOrOrganizer
                ? `
              <div style="font-size: 10px; color: #374151; line-height: 1.6; margin-top: 4px;">
                ${dateMode === "auto" ? dates.d2.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
              </div>
              <div style="font-size: 10px; color: #374151;">
                ${dateMode === "auto" ? (teacher?.district ? teacher.district + ", " : "") + dates.d2.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
              </div>
            `
                : `<div style="height: 32px;"></div>`
            }
            <div style="font-weight: bold; margin-top: 8px; font-size: 12px;">នាយក/នាយិកាសាលា</div>
            <div style="height: 55px;"></div>
          </div>
          <div class="sig-col">
            <div style="font-size: 10px; color: #374151; line-height: 1.6; margin-top: 4px;">
              ${dateMode === "auto" ? dates.d0.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
            </div>
            <div style="font-size: 10px; color: #374151;">
              ${dateMode === "auto" ? (teacher?.district ? teacher.district + ", " : "") + dates.d0.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
            </div>
            <div style="font-weight: bold; margin-top: 8px; font-size: 12px;">${sig1Role}</div>
            <div style="height: 55px;"></div>
            <div style="font-weight: bold; color: #1e3a8a; font-size: 12px;">${teacher?.fullName || "…………………………"}</div>
          </div>
        </div>
      </body>
      </html>
    `;

    printHTML(htmlContent);
  };

  // Print Monthly Grades Report via printHTML
  const handlePrintMonthlyGrades = () => {
    const rowsHtml = classMonthlyStats
      .map((st) => {
        const ev =
          st.gradeCounts.A +
          st.gradeCounts.B +
          st.gradeCounts.C +
          st.gradeCounts.D +
          st.gradeCounts.E +
          st.gradeCounts.F;
        const pass =
          st.gradeCounts.A + st.gradeCounts.B + st.gradeCounts.C + st.gradeCounts.D + st.gradeCounts.E;
        const pPct = ev > 0 ? ((pass / ev) * 100).toFixed(1) : "0.0";
        const def = st.gradeCounts.D + st.gradeCounts.E + st.gradeCounts.F;

        return `
          <tr>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;background-color:#f8fafc;">${st.className}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">—</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;">${st.totalStudents}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;">${st.femaleStudents}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#1e3a8a;">${st.gradeCounts.A || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#0369a1;">${st.gradeCounts.B || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#047857;">${st.gradeCounts.C || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#b45309;">${st.gradeCounts.D || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#c2410c;">${st.gradeCounts.E || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#991b1b;">${st.gradeCounts.F || 0}</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#065f46;background-color:#ecfdf5;">${pPct}%</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;font-weight:bold;color:#9a3412;">${def} នាក់</td>
            <td style="border:1px solid #334155;padding:6px 4px;text-align:center;"></td>
          </tr>
        `;
      })
      .join("");

    const totalEv = totalEvaluated;
    const totalP = passCount;
    const totalPPct = passPct;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8" />
        <title>របាយការណ៍ស្ថិតិនិទ្ទេសតាមខែ_${MONTHS[selMonth]}</title>
        <style>
          @page { size: A4 landscape; margin: 10mm; }
          body { font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', sans-serif; font-size: 12px; color: #0f172a; margin: 0; padding: 10px; }
          table { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 11px; }
          th, td { border: 1px solid #334155; text-align: center; }
          th { background-color: #f1f5f9; padding: 6px 2px; font-weight: bold; }
          .header-box { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
          .sig-box { display: flex; justify-content: space-between; margin-top: 30px; }
          .sig-col { text-align: center; width: 40%; font-size: 12px; }
        </style>
      </head>
      <body>
        <div style="text-align: center; margin-bottom: 12px;">
          <h2 style="margin: 0; font-size: 15px; font-weight: 900;">ព្រះរាជាណាចក្រកម្ពុជា</h2>
          <h3 style="margin: 0; font-size: 13px; font-weight: 900;">ជាតិ សាសនា ព្រះមហាក្សត្រ</h3>
          <div style="font-size: 11px; color: #b45309; margin-top: 2px;">꧁ ༺ ༻ ꧂</div>
        </div>

        <div class="header-box">
          <div style="font-size: 12px; line-height: 1.5; font-weight: bold;">
            <div>រដ្ឋបាលខេត្ត: ${teacher?.province || "……………………"}</div>
            <div>ការិយាល័យអប់រំ យុវជន និងកីឡា: ${teacher?.district || "……………………"}</div>
            <div>សាលារៀន: ${teacher?.school || "សាលាបឋមសិក្សា"}</div>
          </div>
        </div>

        <h1 style="text-align: center; font-size: 16px; font-weight: 900; margin: 12px 0 6px 0; color: #1e3a8a;">
          ស្ថិតិលទ្ធផលនិទ្ទេសសិស្សទូទាំងសាលា ប្រចាំ${MONTHS[selMonth]} ឆ្នាំសិក្សា ២០២៥-២០២៦
        </h1>

        <table border="1" cellpadding="0" cellspacing="0">
          <thead>
            <tr>
              <th rowspan="2" style="width: 70px;">ថ្នាក់</th>
              <th rowspan="2" style="width: 140px;">ឈ្មោះគ្រូបង្រៀន</th>
              <th colspan="2">ចំនួនសិស្ស</th>
              <th colspan="6">ចំនួនសិស្សទទួលបាននិទ្ទេសនីមួយៗ</th>
              <th rowspan="2" style="width: 65px;">ភាគរយ ជាប់</th>
              <th rowspan="2" style="width: 70px;">សិស្សរៀន យឺត</th>
              <th rowspan="2" style="width: 110px;">វិធានការ/ ផែនការបំប៉ន</th>
            </tr>
            <tr>
              <th style="width: 45px;">សរុប</th>
              <th style="width: 40px;">ស្រី</th>
              <th style="width: 38px; color: #1e3a8a;">A</th>
              <th style="width: 38px; color: #0369a1;">B</th>
              <th style="width: 38px; color: #047857;">C</th>
              <th style="width: 38px; color: #b45309;">D</th>
              <th style="width: 38px; color: #c2410c;">E</th>
              <th style="width: 38px; color: #991b1b;">F</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <tr style="background-color: #f1f5f9; font-weight: bold; font-size: 12px;">
              <td colspan="2" style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900;">សរុបសាលា</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900;">${totalStudents}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900;">${totalFemales}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #1e3a8a;">${totalGrades.A}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #0369a1;">${totalGrades.B}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #047857;">${totalGrades.C}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #b45309;">${totalGrades.D}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #c2410c;">${totalGrades.E}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #991b1b;">${totalGrades.F}</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #065f46; background-color: #ecfdf5;">${totalPPct}%</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center; font-weight: 900; color: #9a3412;">${defCount} នាក់</td>
              <td style="border: 1px solid #334155; padding: 8px 4px; text-align: center;"></td>
            </tr>
          </tbody>
        </table>

        <div class="sig-box">
          <div class="sig-col">
            <div style="font-weight: bold; font-size: 13px;">បានឃើញ និងឯកភាព</div>
            ${
              isTeacherOrOrganizer
                ? `
              <div style="font-size: 10px; color: #374151; line-height: 1.6; margin-top: 4px;">
                ${dateMode === "auto" ? dates.d2.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
              </div>
              <div style="font-size: 10px; color: #374151;">
                ${dateMode === "auto" ? (teacher?.district ? teacher.district + ", " : "") + dates.d2.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
              </div>
            `
                : `<div style="height: 32px;"></div>`
            }
            <div style="font-weight: bold; margin-top: 8px; font-size: 12px;">នាយក/នាយិកាសាលា</div>
            <div style="height: 55px;"></div>
          </div>
          <div class="sig-col">
            <div style="font-size: 10px; color: #374151; line-height: 1.6; margin-top: 4px;">
              ${dateMode === "auto" ? dates.d0.lunar : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
            </div>
            <div style="font-size: 10px; color: #374151;">
              ${dateMode === "auto" ? (teacher?.district ? teacher.district + ", " : "") + dates.d0.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
            </div>
            <div style="font-weight: bold; margin-top: 8px; font-size: 12px;">${sig1Role}</div>
            <div style="height: 55px;"></div>
            <div style="font-weight: bold; color: #1e3a8a; font-size: 12px;">${teacher?.fullName || "…………………………"}</div>
          </div>
        </div>
      </body>
      </html>
    `;

    printHTML(htmlContent);
  };

  // Monthly stats calculations
  const totalStudents = classMonthlyStats.reduce((a, b) => a + b.totalStudents, 0);
  const totalFemales = classMonthlyStats.reduce((a, b) => a + b.femaleStudents, 0);
  const totalGrades = classMonthlyStats.reduce(
    (acc, cur) => {
      acc.A += cur.gradeCounts.A;
      acc.B += cur.gradeCounts.B;
      acc.C += cur.gradeCounts.C;
      acc.D += cur.gradeCounts.D;
      acc.E += cur.gradeCounts.E;
      acc.F += cur.gradeCounts.F;
      return acc;
    },
    { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 }
  );

  const totalEvaluated =
    totalGrades.A + totalGrades.B + totalGrades.C + totalGrades.D + totalGrades.E + totalGrades.F;
  const defCount = totalGrades.D + totalGrades.E + totalGrades.F;
  const defPct = totalEvaluated > 0 ? ((defCount / totalEvaluated) * 100).toFixed(1) : "0";
  const passCount = totalGrades.A + totalGrades.B + totalGrades.C + totalGrades.D + totalGrades.E;
  const passPct = totalEvaluated > 0 ? ((passCount / totalEvaluated) * 100).toFixed(1) : "0";

  return (
    <div className="p-4 max-w-7xl mx-auto space-y-4">
      {/* Top Header & Tab Switcher */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs no-print flex flex-wrap justify-between items-center gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
            🏫 របាយការណ៍សាលារៀន (School Academic Reports)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {teacher?.school || "សាលាបឋមសិក្សា"} — របាយការណ៍លទ្ធផលសិក្សាដំណាច់ឆ្នាំ (A=5+6+7) & ស្ថិតិនិទ្ទេសតាមខែ/ឆមាស
          </p>
        </div>

        {/* View Mode Selector Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setReportMode("annual")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              reportMode === "annual"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
            }`}
          >
            <span>📑</span>
            <span>លទ្ធផលសិក្សាដំណាច់ឆ្នាំ</span>
          </button>
          <button
            onClick={() => setReportMode("monthly_grades")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              reportMode === "monthly_grades"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
            }`}
          >
            <span>📊</span>
            <span>ស្ថិតិនិទ្ទេសតាមខែ/ឆមាស (A-F)</span>
          </button>
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* 1. ANNUAL REPORT VIEW (លទ្ធផលសិក្សាដំណាច់ឆ្នាំ A=5+6+7) */}
      {/* ---------------------------------------------------- */}
      {reportMode === "annual" && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs no-print flex flex-wrap justify-between items-center gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {/* Grouping Mode */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
                <span className="text-slate-500 text-[11px] pl-1">ការបង្ហាញ:</span>
                <button
                  onClick={() => setGroupingMode("grade")}
                  className={`px-2.5 py-1 rounded-md text-xs font-bold transition ${
                    groupingMode === "grade"
                      ? "bg-blue-600 text-white"
                      : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                  }`}
                >
                  ថ្នាក់ទី ១ ដល់ ៦
                </button>
                <button
                  onClick={() => setGroupingMode("class")}
                  className={`px-2.5 py-1 rounded-md text-xs font-bold transition ${
                    groupingMode === "class"
                      ? "bg-blue-600 text-white"
                      : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                  }`}
                >
                  តាមបន្ទប់ (1A, 1B...)
                </button>
              </div>

              {/* Number Format Toggle */}
              <button
                onClick={() => setUseKhmerNums(!useKhmerNums)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition flex items-center gap-1 ${
                  useKhmerNums
                    ? "bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200"
                    : "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300"
                }`}
              >
                <span>{useKhmerNums ? "🇰🇭 លេខខ្មែរ (១២៣)" : "🔢 លេខសកល (123)"}</span>
              </button>

              {/* Signatory #1 Role Selector */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
                <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">✍️ ហត្ថលេខាទី១:</span>
                <select
                  value={sig1Role}
                  onChange={(e) => setSig1Role(e.target.value)}
                  className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
                >
                  <option value="អ្នករៀបចំរបាយការណ៍">អ្នករៀបចំរបាយការណ៍</option>
                  <option value="គ្រូប្រចាំថ្នាក់">គ្រូប្រចាំថ្នាក់</option>
                  <option value="មន្ត្រីការិយាល័យ">មន្ត្រីការិយាល័យ</option>
                  <option value="លេខាធិការ">លេខាធិការ</option>
                  <option value="បេឡាធិការ">បេឡាធិការ</option>
                  <option value="ហេរញ្ញិក">ហេរញ្ញិក</option>
                </select>
              </div>

              {/* Date Format Selector */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
                <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">📅 កាលបរិច្ឆេទ:</span>
                <select
                  value={dateMode}
                  onChange={(e) => setDateMode(e.target.value as "auto" | "dots")}
                  className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
                >
                  <option value="auto">ស្វ័យប្រវត្តិ (តាមខែ)</option>
                  <option value="dots">ចុចជួរ (... បោះពុម្ព)</option>
                </select>
              </div>

              {/* Adjustment mode button */}
              <button
                onClick={() => setIsEditingAdjustments(!isEditingAdjustments)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition flex items-center gap-1 ${
                  isEditingAdjustments
                    ? "bg-emerald-600 text-white border-emerald-600"
                    : "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200"
                }`}
              >
                <span>✏️ {isEditingAdjustments ? "រួចរាល់ (Done)" : "កែសម្រួលតេស្ដជាប់/បោះបង់"}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={fetchAllSchoolData}
                className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1"
              >
                🔄 ធ្វើបច្ចុប្បន្នភាព
              </button>

              <button
                onClick={exportAnnualToExcel}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5"
              >
                📥 ទាញយកជា Excel
              </button>

              <button
                onClick={handlePrintAnnual}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5"
              >
                🖨️ បោះពុម្ពតារាងដំណាច់ឆ្នាំ
              </button>
            </div>
          </div>

          {/* Quick Stat Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 no-print">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សដំណាច់ឆ្នាំ (A=5+6+7)</div>
              <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                {annualTotal.colA_total}{" "}
                <span className="text-xs text-slate-500 font-normal">(ស្រី {annualTotal.colA_female})</span>
              </div>
              <div className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">
                សិស្សចុងឆ្នាំ (B): {annualTotal.colB_total} នាក់
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">ជាប់ចុងឆ្នាំ (5=3+4)</div>
              <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                {annualTotal.col5_total}{" "}
                <span className="text-xs text-slate-500 font-normal">(ស្រី {annualTotal.col5_female})</span>
              </div>
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">
                អត្រាជាប់:{" "}
                {annualTotal.colB_total > 0
                  ? ((annualTotal.col5_total / annualTotal.colB_total) * 100).toFixed(1)
                  : "0"}
                %
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សត្រួតថ្នាក់ (6)</div>
              <div className="text-2xl font-black text-red-600 dark:text-red-400 mt-1">
                {annualTotal.col6_total}{" "}
                <span className="text-xs text-slate-500 font-normal">(ស្រី {annualTotal.col6_female})</span>
              </div>
              <div className="text-[11px] text-red-600 dark:text-red-400 mt-0.5">
                អត្រាត្រួតថ្នាក់:{" "}
                {annualTotal.colB_total > 0
                  ? ((annualTotal.col6_total / annualTotal.colB_total) * 100).toFixed(1)
                  : "0"}
                %
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សបោះបង់ (7)</div>
              <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
                {annualTotal.col7_total}{" "}
                <span className="text-xs text-slate-500 font-normal">(ស្រី {annualTotal.col7_female})</span>
              </div>
              <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">
                អត្រាបោះបង់:{" "}
                {annualTotal.colA_total > 0
                  ? ((annualTotal.col7_total / annualTotal.colA_total) * 100).toFixed(1)
                  : "0"}
                %
              </div>
            </div>
          </div>

          {/* Adjustment Guidance Notice */}
          {isEditingAdjustments && (
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-3 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
              <span className="text-base">💡</span>
              <div className="space-y-1">
                <div className="font-bold">របៀបកែសម្រួលទិន្នន័យបន្ថែម (In-Table Adjustments):</div>
                <div>
                  លោកគ្រូអ្នកគ្រូអាចបញ្ចូលចំនួនសិស្ស <strong>«ធ្វើតេស្ដជាប់ (៤)»</strong> និង <strong>«សិស្សបោះបង់ (៧)»</strong> ផ្ទាល់ក្នុងតារាងខាងក្រោម។ រូបមន្ត <strong>A=5+6+7</strong>, <strong>B=5+6</strong>, <strong>5=3+4</strong> និង <strong>សរុប</strong> នឹងធ្វើបច្ចុប្បន្នភាពដោយស្វ័យប្រវត្តិភ្លាមៗ!
                </div>
              </div>
            </div>
          )}

          {/* Main Table Card */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-slate-900 dark:text-slate-100 overflow-hidden">
            {/* Title Header */}
            <div className="text-center mb-4 space-y-1">
              <h1 className="text-base md:text-lg font-black text-blue-900 dark:text-blue-400 uppercase">
                លទ្ធផលសិក្សាដំណាច់ឆ្នាំ
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {teacher?.school || "សាលាបឋមសិក្សា"} · ឆ្នាំសិក្សា ២០២៥-២០២៦
              </p>
            </div>

            {loadingAll ? (
              <div className="py-12 text-center text-slate-500 space-y-2">
                <div className="text-2xl animate-spin inline-block">⏳</div>
                <div className="text-xs font-semibold">កំពុងទាញយកទិន្នន័យគ្រប់ថ្នាក់ទាំងអស់ពី Firestore...</div>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-slate-300 dark:border-slate-700 text-xs">
                  <tbody>
                    {/* Header Row 1 */}
                    <tr className="bg-slate-100 dark:bg-slate-800/80 font-bold">
                      <td
                        rowSpan={4}
                        className="border border-slate-300 dark:border-slate-700 py-2.5 px-2 text-center w-14 font-black"
                      >
                        <p className="text-center m-0">ថ្នាក់ទី</p>
                      </td>
                      <td
                        colSpan={14}
                        className="border border-slate-300 dark:border-slate-700 py-2 px-2 text-center text-blue-900 dark:text-blue-300 font-black text-sm bg-blue-50/60 dark:bg-blue-950/40"
                      >
                        <p className="text-center m-0">លទ្ធផលសិក្សារបស់សិស្ស</p>
                      </td>
                    </tr>

                    {/* Header Row 2 */}
                    <tr className="bg-slate-50 dark:bg-slate-800/50 font-bold text-[11px] text-slate-800 dark:text-slate-200">
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center">
                        <p className="text-center m-0">សិស្សដំណាច់ឆ្នាំ</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center">
                        <p className="text-center m-0">សិស្សចុងឆ្នាំ</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center text-blue-700 dark:text-blue-400">
                        <p className="text-center m-0">ជាប់មធ្យមភាគ</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center">
                        <p className="text-center m-0">ធ្វើតេស្ដជាប់</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300">
                        <p className="text-center m-0">ជាប់ចុងឆ្នាំ</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center text-red-700 dark:text-red-400">
                        <p className="text-center m-0">សិស្សត្រួតថ្នាក់</p>
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1.5 px-1 text-center text-amber-700 dark:text-amber-400">
                        <p className="text-center m-0">សិស្សបោះបង់</p>
                      </td>
                    </tr>

                    {/* Header Row 3 */}
                    <tr className="bg-white dark:bg-slate-900 font-bold text-[11px] text-slate-700 dark:text-slate-300">
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11 text-blue-700 dark:text-blue-400">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10 text-blue-700 dark:text-blue-400">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11 text-red-700 dark:text-red-400">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10 text-red-700 dark:text-red-400">ស្រី</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-11 text-amber-700 dark:text-amber-400">សរុប</td>
                      <td className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center w-10 text-amber-700 dark:text-amber-400">ស្រី</td>
                    </tr>

                    {/* Header Row 4 (Formulas) */}
                    <tr className="bg-slate-100 dark:bg-slate-800 font-bold text-[10px] text-slate-600 dark:text-slate-400">
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center">
                        A=5+6+7
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center">
                        B=5+6
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center text-blue-700 dark:text-blue-400">
                        3
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center">
                        4
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                        5=3+4
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center text-red-700 dark:text-red-400">
                        6
                      </td>
                      <td colSpan={2} className="border border-slate-300 dark:border-slate-700 py-1 px-1 text-center text-amber-700 dark:text-amber-400">
                        7
                      </td>
                    </tr>

                    {/* Data Rows */}
                    {annualRows.map((r, idx) => (
                      <tr
                        key={r.id}
                        className={idx % 2 === 0 ? "bg-slate-50/50 dark:bg-slate-800/30" : "bg-white dark:bg-slate-900"}
                      >
                        {/* ថ្នាក់ទី */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold text-slate-800 dark:text-slate-200">
                          {useKhmerNums ? toKhNum(r.label) : r.label}
                        </td>

                        {/* សិស្សដំណាច់ឆ្នាំ (A=5+6+7) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold">
                          {useKhmerNums ? toKhNum(r.colA_total) : r.colA_total}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-slate-600 dark:text-slate-400">
                          {useKhmerNums ? toKhNum(r.colA_female) : r.colA_female}
                        </td>

                        {/* សិស្សចុងឆ្នាំ (B=5+6) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold">
                          {useKhmerNums ? toKhNum(r.colB_total) : r.colB_total}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-slate-600 dark:text-slate-400">
                          {useKhmerNums ? toKhNum(r.colB_female) : r.colB_female}
                        </td>

                        {/* ជាប់មធ្យមភាគ (3) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold text-blue-700 dark:text-blue-400">
                          {useKhmerNums ? toKhNum(r.col3_total) : r.col3_total}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-blue-600 dark:text-blue-400">
                          {useKhmerNums ? toKhNum(r.col3_female) : r.col3_female}
                        </td>

                        {/* ធ្វើតេស្ដជាប់ (4) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center">
                          {isEditingAdjustments ? (
                            <input
                              type="number"
                              min={0}
                              value={adjustments[r.id]?.retestPassedTotal || 0}
                              onChange={(e) =>
                                handleAdjustmentChange(r.id, "retestPassedTotal", parseInt(e.target.value) || 0)
                              }
                              className="w-10 text-center py-0.5 px-1 bg-white dark:bg-slate-800 border border-blue-400 rounded text-xs font-bold"
                            />
                          ) : (
                            <span>{useKhmerNums ? toKhNum(r.col4_total) : r.col4_total}</span>
                          )}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-slate-600 dark:text-slate-400">
                          {isEditingAdjustments ? (
                            <input
                              type="number"
                              min={0}
                              value={adjustments[r.id]?.retestPassedFemale || 0}
                              onChange={(e) =>
                                handleAdjustmentChange(r.id, "retestPassedFemale", parseInt(e.target.value) || 0)
                              }
                              className="w-10 text-center py-0.5 px-1 bg-white dark:bg-slate-800 border border-blue-400 rounded text-xs font-bold"
                            />
                          ) : (
                            <span>{useKhmerNums ? toKhNum(r.col4_female) : r.col4_female}</span>
                          )}
                        </td>

                        {/* ជាប់ចុងឆ្នាំ (5=3+4) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-extrabold text-emerald-700 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/20">
                          {useKhmerNums ? toKhNum(r.col5_total) : r.col5_total}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/20">
                          {useKhmerNums ? toKhNum(r.col5_female) : r.col5_female}
                        </td>

                        {/* សិស្សត្រួតថ្នាក់ (6) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center font-bold text-red-600 dark:text-red-400">
                          {useKhmerNums ? toKhNum(r.col6_total) : r.col6_total}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-red-500 dark:text-red-400">
                          {useKhmerNums ? toKhNum(r.col6_female) : r.col6_female}
                        </td>

                        {/* សិស្សបោះបង់ (7) */}
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center">
                          {isEditingAdjustments ? (
                            <input
                              type="number"
                              min={0}
                              value={adjustments[r.id]?.dropoutTotal || 0}
                              onChange={(e) =>
                                handleAdjustmentChange(r.id, "dropoutTotal", parseInt(e.target.value) || 0)
                              }
                              className="w-10 text-center py-0.5 px-1 bg-white dark:bg-slate-800 border border-amber-400 rounded text-xs font-bold"
                            />
                          ) : (
                            <span className="font-bold text-amber-700 dark:text-amber-400">
                              {useKhmerNums ? toKhNum(r.col7_total) : r.col7_total}
                            </span>
                          )}
                        </td>
                        <td className="border border-slate-300 dark:border-slate-700 py-2 px-1 text-center text-amber-600 dark:text-amber-400">
                          {isEditingAdjustments ? (
                            <input
                              type="number"
                              min={0}
                              value={adjustments[r.id]?.dropoutFemale || 0}
                              onChange={(e) =>
                                handleAdjustmentChange(r.id, "dropoutFemale", parseInt(e.target.value) || 0)
                              }
                              className="w-10 text-center py-0.5 px-1 bg-white dark:bg-slate-800 border border-amber-400 rounded text-xs font-bold"
                            />
                          ) : (
                            <span>{useKhmerNums ? toKhNum(r.col7_female) : r.col7_female}</span>
                          )}
                        </td>
                      </tr>
                    ))}

                    {/* Total Row */}
                    <tr className="bg-slate-200/90 dark:bg-slate-800 font-black text-slate-900 dark:text-white border-t-2 border-slate-400">
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black">
                        សរុប
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black">
                        {useKhmerNums ? toKhNum(annualTotal.colA_total) : annualTotal.colA_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-slate-700 dark:text-slate-300">
                        {useKhmerNums ? toKhNum(annualTotal.colA_female) : annualTotal.colA_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black">
                        {useKhmerNums ? toKhNum(annualTotal.colB_total) : annualTotal.colB_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-slate-700 dark:text-slate-300">
                        {useKhmerNums ? toKhNum(annualTotal.colB_female) : annualTotal.colB_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-blue-900 dark:text-blue-300">
                        {useKhmerNums ? toKhNum(annualTotal.col3_total) : annualTotal.col3_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-blue-900 dark:text-blue-300">
                        {useKhmerNums ? toKhNum(annualTotal.col3_female) : annualTotal.col3_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black">
                        {useKhmerNums ? toKhNum(annualTotal.col4_total) : annualTotal.col4_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-slate-700 dark:text-slate-300">
                        {useKhmerNums ? toKhNum(annualTotal.col4_female) : annualTotal.col4_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-emerald-900 dark:text-emerald-300 bg-emerald-100/70 dark:bg-emerald-950/40">
                        {useKhmerNums ? toKhNum(annualTotal.col5_total) : annualTotal.col5_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-emerald-900 dark:text-emerald-300 bg-emerald-100/70 dark:bg-emerald-950/40">
                        {useKhmerNums ? toKhNum(annualTotal.col5_female) : annualTotal.col5_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-red-900 dark:text-red-300">
                        {useKhmerNums ? toKhNum(annualTotal.col6_total) : annualTotal.col6_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-red-900 dark:text-red-300">
                        {useKhmerNums ? toKhNum(annualTotal.col6_female) : annualTotal.col6_female}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-amber-900 dark:text-amber-300">
                        {useKhmerNums ? toKhNum(annualTotal.col7_total) : annualTotal.col7_total}
                      </td>
                      <td className="border border-slate-300 dark:border-slate-700 py-2.5 px-1 text-center font-black text-amber-900 dark:text-amber-300">
                        {useKhmerNums ? toKhNum(annualTotal.col7_female) : annualTotal.col7_female}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Signature Footer for Annual Official View */}
              <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between gap-8 text-xs text-slate-800 dark:text-slate-200">
                {/* Left Block: នាយក/នាយិកាសាលា */}
                <div className="flex-1 text-center">
                  <div className="font-bold text-sm text-slate-900 dark:text-white">បានឃើញ និងឯកភាព</div>

                  {isTeacherOrOrganizer ? (
                    <div className="my-2 text-center text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                      <div>
                        {dateMode === "auto"
                          ? dates.d2.lunar
                          : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
                      </div>
                      <div>
                        {dateMode === "auto"
                          ? (teacher?.district ? teacher.district + ", " : "") + dates.d2.solar
                          : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
                      </div>
                    </div>
                  ) : (
                    <div className="my-2 min-h-[32px]"></div>
                  )}

                  <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">នាយក/នាយិកាសាលា</div>
                  <div className="h-16"></div>
                </div>

                {/* Right Block: ហត្ថលេខាទី១ (អ្នករៀបចំ/គ្រូប្រចាំថ្នាក់/មន្ត្រី...) */}
                <div className="flex-1 text-center">
                  <div className="my-2 text-center text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                    <div>
                      {dateMode === "auto"
                        ? dates.d0.lunar
                        : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
                    </div>
                    <div>
                      {dateMode === "auto"
                        ? (teacher?.district ? teacher.district + ", " : "") + dates.d0.solar
                        : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}
                    </div>
                  </div>

                  <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">{sig1Role}</div>
                  <div className="font-extrabold text-blue-950 dark:text-blue-300 mt-12">
                    {teacher?.fullName || "…………………………"}
                  </div>
                </div>
              </div>
            </>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 2. MONTHLY GRADES REPORT VIEW (ស្ថិតិនិទ្ទេស A-F)    */}
      {/* ---------------------------------------------------- */}
      {reportMode === "monthly_grades" && (
        <div className="space-y-4">
          {/* Header controls */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs no-print flex flex-wrap justify-between items-center gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {/* Semester Selector */}
              <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                {SEMESTERS.filter((s) => s.id !== "annual").map((sm) => (
                  <button
                    key={sm.id}
                    onClick={() => {
                      setSemesterId(sm.id);
                      setSelMonth(sm.months[0]);
                    }}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition ${
                      semesterId === sm.id
                        ? "bg-blue-600 text-white shadow-xs"
                        : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                    }`}
                  >
                    {sm.label}
                  </button>
                ))}
              </div>

              {/* Month Selector */}
              <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                {curSem.months.map((mIdx) => (
                  <button
                    key={mIdx}
                    onClick={() => setSelMonth(mIdx)}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold transition ${
                      selMonth === mIdx
                        ? "bg-slate-900 text-white shadow-xs dark:bg-blue-500"
                        : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700"
                    }`}
                  >
                    ខែ{MONTHS[mIdx]}
                  </button>
                ))}
              </div>

              {/* Signatory #1 Role Selector */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
                <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">✍️ ហត្ថលេខាទី១:</span>
                <select
                  value={sig1Role}
                  onChange={(e) => setSig1Role(e.target.value)}
                  className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
                >
                  <option value="អ្នករៀបចំរបាយការណ៍">អ្នករៀបចំរបាយការណ៍</option>
                  <option value="គ្រូប្រចាំថ្នាក់">គ្រូប្រចាំថ្នាក់</option>
                  <option value="មន្ត្រីការិយាល័យ">មន្ត្រីការិយាល័យ</option>
                  <option value="លេខាធិការ">លេខាធិការ</option>
                  <option value="បេឡាធិការ">បេឡាធិការ</option>
                  <option value="ហេរញ្ញិក">ហេរញ្ញិក</option>
                </select>
              </div>

              {/* Date Format Selector */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-bold">
                <span className="text-slate-600 dark:text-slate-400 text-[11px] pl-1">📅 កាលបរិច្ឆេទ:</span>
                <select
                  value={dateMode}
                  onChange={(e) => setDateMode(e.target.value as "auto" | "dots")}
                  className="bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-md px-2 py-1 text-xs font-bold outline-none"
                >
                  <option value="auto">ស្វ័យប្រវត្តិ (តាមខែ)</option>
                  <option value="dots">ចុចជួរ (... បោះពុម្ព)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={fetchAllSchoolData}
                className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1"
              >
                🔄 ធ្វើបច្ចុប្បន្នភាព
              </button>

              <button
                onClick={handlePrintMonthlyGrades}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5"
              >
                🖨️ បោះពុម្ពរបាយការណ៍និទ្ទេស
              </button>
            </div>
          </div>

          {/* Summary Stat Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 no-print">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សសរុប (គ្រប់ថ្នាក់)</div>
              <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                {totalStudents} <span className="text-xs text-slate-500 font-normal">(ស្រី {totalFemales})</span>
              </div>
              <div className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">
                បានវាយតម្លៃ {totalEvaluated} នាក់
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">អត្រាសិស្សជាប់ (A-E)</div>
              <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                {passPct}% <span className="text-xs text-slate-500 font-normal">({passCount} នាក់)</span>
              </div>
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">និទ្ទេស A-E</div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">សិស្សរៀនយឺត (DEF)</div>
              <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
                {defCount} <span className="text-xs font-normal text-amber-700">({defPct}%)</span>
              </div>
              <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">ត្រូវការផែនការជួយបំប៉ន</div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">និទ្ទេស A & B (ល្អប្រសើរ)</div>
              <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
                {totalGrades.A + totalGrades.B}{" "}
                <span className="text-xs text-slate-500 font-normal">
                  ({totalEvaluated > 0 ? (((totalGrades.A + totalGrades.B) / totalEvaluated) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">
                A: {totalGrades.A} | B: {totalGrades.B}
              </div>
            </div>
          </div>

          {/* Main Print Container & Table */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-slate-900 dark:text-slate-100">
            {/* Print Header */}
            <div className="text-center w-full mb-4">
              <h2 className="text-sm font-black text-blue-900 dark:text-blue-400 leading-snug">
                ព្រះរាជាណាចក្រកម្ពុជា
                <br />
                ជាតិ សាសនា ព្រះមហាក្សត្រ
              </h2>
              <div className="text-[10px] text-amber-800 dark:text-amber-500 mt-0.5 font-normal">꧁ ༺ ༻ ꧂</div>
            </div>

            <div className="flex justify-between items-start gap-4 mb-2">
              <div className="text-xs text-slate-900 dark:text-slate-200 leading-snug font-bold">
                <div>រដ្ឋបាលស្រុក: {teacher?.district || "……………………"}</div>
                <div>ការិយាល័យអប់រំ យុវជន និងកីឡា</div>
                <div>{teacher?.school || "សាលាបឋមសិក្សា"}</div>
              </div>
            </div>

            <hr className="border-t-2 border-slate-900 dark:border-slate-700 mb-3" />

            <div className="text-center mb-4 space-y-1">
              <h3 className="font-black text-base text-blue-800 dark:text-blue-400 uppercase mt-2">
                របាយការណ៍សរុបលទ្ធផលនិទ្ទេសសិក្សា (ខែ{MONTHS[selMonth]} {curSem.label})
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400">គ្រប់ថ្នាក់ទាំងអស់ ក្នុងសាលារៀន</p>
            </div>

            {loadingAll ? (
              <div className="py-12 text-center text-slate-500 space-y-2">
                <div className="text-2xl animate-spin inline-block">⏳</div>
                <div className="text-xs font-semibold">កំពុងទាញយកទិន្នន័យគ្រប់ថ្នាក់ទាំងអស់ពី Firestore...</div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-slate-300 text-xs">
                  <thead>
                    <tr className="bg-blue-100/90 border border-slate-300 text-slate-900 font-bold">
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-8">
                        ល.រ
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-2 text-center min-w-[60px]">
                        ថ្នាក់
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-12">
                        សិស្សសរុប
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-10">
                        ស្រី
                      </th>
                      <th colSpan={6} className="border border-slate-300 py-1 px-1 text-center bg-blue-200/80">
                        ចំនួនសិស្សទទួលបាននិទ្ទេស (A - F)
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-14 bg-emerald-100">
                        អត្រាជាប់ (A-E)
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center w-14 bg-amber-100">
                        សិស្សរៀនយឺត (DEF)
                      </th>
                      <th rowSpan={2} className="border border-slate-300 py-2 px-1 text-center min-w-[60px]">
                        មធ្យមភាគថ្នាក់
                      </th>
                    </tr>
                    <tr className="bg-blue-50 border border-slate-300 text-slate-800 font-bold">
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-blue-700 bg-blue-50">
                        និទ្ទេសA
                      </th>
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-cyan-700 bg-cyan-50">
                        និទ្ទេសB
                      </th>
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-emerald-700 bg-emerald-50">
                        និទ្ទេសC
                      </th>
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-amber-700 bg-amber-50">
                        និទ្ទេសD
                      </th>
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-orange-700 bg-orange-50">
                        និទ្ទេសE
                      </th>
                      <th className="border border-slate-300 py-1.5 px-1 text-center text-red-700 bg-red-50">
                        និទ្ទេសF
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {classMonthlyStats.map((st, idx) => {
                      const evalCount =
                        st.gradeCounts.A +
                        st.gradeCounts.B +
                        st.gradeCounts.C +
                        st.gradeCounts.D +
                        st.gradeCounts.E +
                        st.gradeCounts.F;
                      const cPass =
                        st.gradeCounts.A +
                        st.gradeCounts.B +
                        st.gradeCounts.C +
                        st.gradeCounts.D +
                        st.gradeCounts.E;
                      const cPassPct = evalCount > 0 ? ((cPass / evalCount) * 100).toFixed(0) + "%" : "—";
                      const cDEF = st.gradeCounts.D + st.gradeCounts.E + st.gradeCounts.F;

                      return (
                        <tr key={st.className} className={idx % 2 === 0 ? "bg-slate-50/50" : "bg-white"}>
                          <td className="border border-slate-300 py-2 px-1 text-center font-medium text-slate-500">
                            {idx + 1}
                          </td>
                          <td className="border border-slate-300 py-2 px-2 text-center font-extrabold text-blue-900">
                            ថ្នាក់ {st.className}
                          </td>
                          <td className="border border-slate-300 py-2 px-1 text-center font-bold">{st.totalStudents}</td>
                          <td className="border border-slate-300 py-2 px-1 text-center text-slate-700">
                            {st.femaleStudents}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-blue-700 bg-blue-50/30">
                            {st.gradeCounts.A > 0 ? (
                              <span>
                                {st.gradeCounts.A}{" "}
                                <span className="text-[10px] text-blue-500 font-normal">
                                  ({((st.gradeCounts.A / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-cyan-700 bg-cyan-50/30">
                            {st.gradeCounts.B > 0 ? (
                              <span>
                                {st.gradeCounts.B}{" "}
                                <span className="text-[10px] text-cyan-600 font-normal">
                                  ({((st.gradeCounts.B / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-emerald-700 bg-emerald-50/30">
                            {st.gradeCounts.C > 0 ? (
                              <span>
                                {st.gradeCounts.C}{" "}
                                <span className="text-[10px] text-emerald-600 font-normal">
                                  ({((st.gradeCounts.C / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-amber-700 bg-amber-50/30">
                            {st.gradeCounts.D > 0 ? (
                              <span>
                                {st.gradeCounts.D}{" "}
                                <span className="text-[10px] text-amber-600 font-normal">
                                  ({((st.gradeCounts.D / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-orange-700 bg-orange-50/30">
                            {st.gradeCounts.E > 0 ? (
                              <span>
                                {st.gradeCounts.E}{" "}
                                <span className="text-[10px] text-orange-600 font-normal">
                                  ({((st.gradeCounts.E / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-extrabold text-red-700 bg-red-50/30">
                            {st.gradeCounts.F > 0 ? (
                              <span>
                                {st.gradeCounts.F}{" "}
                                <span className="text-[10px] text-red-500 font-normal">
                                  ({((st.gradeCounts.F / (evalCount || 1)) * 100).toFixed(0)}%)
                                </span>
                              </span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-black text-emerald-800 bg-emerald-50/60">
                            {cPassPct}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-black text-amber-800 bg-amber-50/60">
                            {cDEF > 0 ? `${cDEF} នាក់` : "០"}
                          </td>

                          <td className="border border-slate-300 py-2 px-1 text-center font-bold text-slate-800">
                            {st.avgScore !== null ? fmtAvg(st.avgScore) : "—"}
                          </td>
                        </tr>
                      );
                    })}

                    {/* Total Row */}
                    <tr className="bg-blue-100/90 font-black text-slate-900 border-t-2 border-slate-400">
                      <td colSpan={2} className="border border-slate-300 py-2.5 px-2 text-center">
                        សរុបសាលា
                      </td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center">{totalStudents}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center">{totalFemales}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-blue-900">{totalGrades.A}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-cyan-900">{totalGrades.B}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-emerald-900">
                        {totalGrades.C}
                      </td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-amber-900">{totalGrades.D}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-orange-900">
                        {totalGrades.E}
                      </td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-red-900">{totalGrades.F}</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-emerald-900">{passPct}%</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center text-amber-900">{defCount} នាក់</td>
                      <td className="border border-slate-300 py-2.5 px-1 text-center">—</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Signature Footer for Official Printing */}
            <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between gap-8 text-xs text-slate-800 dark:text-slate-200">
              {/* Left Block: នាយក/នាយិកាសាលា */}
              <div className="flex-1 text-center">
                <div className="font-bold text-sm text-slate-900 dark:text-white">បានឃើញ និងឯកភាព</div>

                {isTeacherOrOrganizer ? (
                  <div className="my-2 text-left text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                    <div>
                      {dateMode === "auto"
                        ? dates.d2.lunar
                        : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
                    </div>
                    <div>{dateMode === "auto" ? dates.d2.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}</div>
                  </div>
                ) : (
                  <div className="my-2 min-h-[32px]"></div>
                )}

                <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">នាយក/នាយិកាសាលា</div>
                <div className="h-16"></div>
              </div>

              {/* Right Block: ហត្ថលេខាទី១ (អ្នករៀបចំ/គ្រូប្រចាំថ្នាក់/មន្ត្រី...) */}
              <div className="flex-1 text-center">
                <div className="my-2 text-left text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                  <div>
                    {dateMode === "auto"
                      ? dates.d0.lunar
                      : "ថ្ងៃ..................... ខែ............ ឆ្នាំ............ ...... ព.ស. ២៥...."}
                  </div>
                  <div>{dateMode === "auto" ? dates.d0.solar : "ថ្ងៃទី........ ខែ........ ឆ្នាំ២០២...."}</div>
                </div>

                <div className="font-bold text-slate-900 dark:text-slate-100 mt-1">{sig1Role}</div>
                <div className="font-extrabold text-blue-950 dark:text-blue-300 mt-12">
                  {teacher?.fullName || "គ្រូបង្រៀន"}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
